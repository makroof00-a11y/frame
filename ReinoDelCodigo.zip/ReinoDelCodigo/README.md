# El Reino del Código

RPG académico por niveles hecho en **Java** para el proyecto de Programación Orientada a Objetos.
El jugador recorre un mapa de salas, derrota "bugs" respondiendo preguntas (de programación o de
cultura general), gana XP y monedas, compra objetos y vence a un jefe al final de cada nivel.

## Cómo abrirlo en NetBeans

**Opción A (recomendada): abrir el proyecto Maven**
1. Descomprime el zip.
2. NetBeans → *File → Open Project* → selecciona la carpeta `ReinoDelCodigo` (NetBeans la reconoce por el `pom.xml`).
3. Clic derecho en el proyecto → *Run* (la clase principal es `rpgacademico.principal.Main`).

**Opción B: proyecto Ant normal ("Java Application")**
1. Crea el proyecto en NetBeans (*Java with Ant → Java Application*) y desmarca "Create Main Class".
2. Copia la carpeta `src/main/java/rpgacademico` dentro de la carpeta `src` del proyecto.
3. Copia la carpeta `recursos` en la **raíz del proyecto** (al lado de `src`, no dentro).
4. Ejecuta `rpgacademico.principal.Main`.

> Importante: la carpeta `recursos` debe quedar junto a `src`. Ahí están los mapas, las preguntas y las instrucciones.

**Sin NetBeans:** `./ejecutar.sh` (Linux/Mac) o `ejecutar.bat` (Windows). Requiere JDK 8 o superior.

## Modos de ejecución

| Comando / argumento | Qué hace |
|---|---|
| (ninguno) | Menús con **JOptionPane** (ventanas). Es la versión principal. |
| `--consola` | Versión de terminal con colores y cajas. Úsala en una terminal externa, no en la salida de NetBeans. |
| `--simple` | Quita emojis y colores (si tu pantalla los muestra mal). |

En NetBeans puedes pasar argumentos en *Properties → Run → Arguments*.

## Cómo se juega

1. *Nueva partida*, escribe tu nombre y elige el modo (Académico, Cultura general o Aventurero).
2. En cada sala eliges hacia dónde ir. Salas: `S` inicio, `.` camino, `E` enemigo, `T` tienda, `C` cofre,
   `K` cofre con la llave, `L` puerta sellada, `J` jefe.
3. Responde bien para atacar con tu mejor habilidad; si fallas pierdes una vida.
4. Consigue la llave (`K`), abre la puerta (`L`) y vence al jefe (3 fases) para pasar al siguiente nivel.
5. Si te quedas sin vidas, el nivel se reinicia (pierdes la mitad de las monedas). Cerrar la pregunta = huir.

Más detalles en `recursos/instrucciones.txt` (el juego lo lee desde el menú).

## Requisitos del profesor y dónde están

| Requisito | Dónde se cumple |
|---|---|
| **Lectura** (archivos y teclado) | `Recursos.leerLineas` (BufferedReader) lee mapas, preguntas e instrucciones; `GuardadoProgreso.cargar` lee la partida; los datos del jugador se leen con `JOptionPane.showInputDialog` (`VistaJOptionPane.pedirTexto` / `preguntar`). |
| **Métodos** | Todo el código está dividido en métodos pequeños con una sola tarea: `Combate.pelear/atacar/fallar/otorgar`, `Juego.explorar/gestionarInventario/guardar`, `Mapa.cargar/dibujar`, `Usuario.ganarExperiencia`, etc. Hay métodos con retorno, con parámetros, `static` y `void`. |
| **Excepciones** | Jerarquía propia bajo `ReinoException`: `MonedasInsuficientesException`, `InventarioLlenoException`, `MapaInvalidoException`, `PreguntaInvalidaException`, `ProgresoException`. Se lanzan con `throw`/`throws` y se atrapan con `try/catch` (incluido multi-catch) y `try-with-resources` para los archivos. |
| **ArrayList** | `Inventario.items`, `Tienda.catalogo`, `Usuario.habilidades`, `RepositorioPreguntas.banco/usadas`, `SalaCombate.enemigos`, y las listas de opciones de cada menú. |
| **Menú con JOptionPane** | `VistaJOptionPane`: `showOptionDialog` (botones), `showInputDialog` (lista desplegable y texto), `showConfirmDialog`, `showMessageDialog`. |

## Conceptos de POO

- **Abstracción y herencia:** `Habilidad` (→ `MetodoCorrecto`, `SintaxisOptima`, `AtaqueCritico`), `Enemigo` (→ `EnemigoOpcionMultiple` → `EnemigoVerdaderoFalso`; `EnemigoTexto`), `Sala` (→ `SalaVacia`, `SalaCombate` → `SalaJefe`, `SalaTienda`, `SalaTesoro`, `SalaBloqueada`).
- **Polimorfismo:** cada habilidad calcula su daño distinto; cada enemigo valida su respuesta y da su pista distinto; cada sala reacciona distinto en `entrar()`; la `Vista` tiene dos implementaciones intercambiables.
- **Interfaces:** `ItemEquipable` (con método `default`) y `Vista`.
- **Composición y agregación:** `Usuario` tiene un `Inventario` y una lista de `Habilidad`; `Inventario` contiene `ItemEquipable`; `Mapa` contiene `Sala`; `SalaTienda` tiene una `Tienda`.
- **Encapsulamiento:** atributos privados, getters, copias defensivas (`getItems()`), y reglas dentro de las clases (`Usuario.perderVida`, `Inventario.agregar`).
- **Enumeraciones:** `Categoria`, `ModoJuego`, `TipoAviso`, `ResultadoSala`, `ResultadoCombate`.
- **Patrones:** *Factory* (`FabricaEnemigos`, `FabricaSalas`, `FabricaItems`), *Strategy* (habilidades), *Template Method* (`SalaCombate.alVencer` que redefine `SalaJefe`).

## Estructura

```
recursos/           mapas (nivel1-3.txt), preguntas.txt, instrucciones.txt
src/main/java/rpgacademico/
  principal/        Main
  nucleo/           Juego (flujo, niveles, guardado)
  combate/          Combate, ResultadoCombate
  modelo/           Usuario, Inventario, Tienda, Categoria, ModoJuego
  habilidades/      Habilidad y sus 3 hijas
  items/            ItemEquipable, 5 objetos, FabricaItems
  enemigos/         Enemigo y sus hijas, FabricaEnemigos
  mundo/            Sala y sus hijas, Mapa, FabricaSalas
  persistencia/     Recursos, RepositorioPreguntas, GuardadoProgreso, DatosProgreso
  excepciones/      ReinoException y 5 hijas
  vista/            Vista, VistaJOptionPane, VistaConsola, Consola, Colores, Iconos
diagrama.puml       diagrama de clases (PlantUML)
```

## Agregar tus propias preguntas

Abre `recursos/preguntas.txt` y agrega una línea (no hace falta tocar el código):

```
TIPO|CATEGORIA|DIFICULTAD|Nombre del enemigo|Pregunta|Respuesta|Opciones
MULTIPLE|HISTORIA|2|Guardián del Tiempo|¿En qué año se firmó la Constitución de 1991?|1991|1886;1953;1991;2001
VF|CIENCIA|1|Gólem|El Sol es una estrella.|Verdadero
SALIDA|PROGRAMACION|1|Bug|System.out.println(2 + 3);  ¿Qué imprime?|5
COMPLETAR|GEOGRAFIA|1|Duende|Escribe la capital de Francia.|París/Paris
```

- Tipos: `MULTIPLE`, `VF`, `SALIDA`, `COMPLETAR`. Dificultad 1, 2 o 3 (= nivel del mapa).
- En las respuestas escritas no importan mayúsculas, tildes ni espacios. Varias respuestas válidas se separan con `/`.
- No uses el carácter `|` dentro de una pregunta. Las líneas que empiezan con `//` son comentarios.
- Si una línea está mal escrita, el juego avisa con el número de línea del error.

Nota sobre historia: la fecha en que Colón llegó a lo que hoy es Colombia es discutida entre historiadores
(suele decirse 1502, y algunos señalan a Alonso de Ojeda en 1499). Por eso el banco usa fechas que no se discuten,
como 1492 para la llegada de Colón a América.

## Mapas

Puedes crear o editar mapas en `recursos/nivelN.txt` (`#` pared). Reglas: rectangular, exactamente una `S`
y una `J`. Si algo está mal, el juego muestra un mensaje explicando qué.
