@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java > fuentes.txt
javac -encoding UTF-8 -d out @fuentes.txt
if errorlevel 1 pause & exit /b 1
java -Dfile.encoding=UTF-8 -cp out rpgacademico.principal.Main %*
