#!/bin/sh
# Compila y ejecuta sin necesidad de NetBeans. Uso: ./ejecutar.sh [--consola] [--simple]
cd "$(dirname "$0")"
mkdir -p out
javac -encoding UTF-8 -d out $(find src -name "*.java") || exit 1
java -Dfile.encoding=UTF-8 -cp out rpgacademico.principal.Main "$@"
