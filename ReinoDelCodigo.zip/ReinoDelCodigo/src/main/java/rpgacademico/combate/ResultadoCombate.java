package rpgacademico.combate;

public enum ResultadoCombate { VICTORIA, HUIDA, DERROTA }
