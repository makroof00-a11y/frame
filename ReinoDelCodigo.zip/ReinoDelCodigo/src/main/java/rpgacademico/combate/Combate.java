package rpgacademico.combate;

import rpgacademico.enemigos.Enemigo;
import rpgacademico.habilidades.Habilidad;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.TipoAviso;
import rpgacademico.vista.Vista;

/** Lógica de un combate: el jugador responde, y si acierta ejecuta un ataque polimórfico. */
public class Combate {

    private final Usuario usuario;
    private final Vista vista;

    public Combate(Usuario usuario, Vista vista) {
        this.usuario = usuario;
        this.vista = vista;
    }

    public ResultadoCombate pelear(Enemigo enemigo) {
        int intentos = 0;
        String pista = null;

        while (usuario.estaVivo()) {
            if (pista == null && usuario.isPistaActiva()) {
                pista = enemigo.darPista();
                usuario.consumirPista();
            }

            long inicio = System.currentTimeMillis();
            String respuesta = vista.preguntar(enemigo, usuario, pista);
            long segundos = (System.currentTimeMillis() - inicio) / 1000;

            if (respuesta == null) {
                if (vista.confirmar("Huir del combate", "¿Quieres huir? El enemigo seguirá esperándote.")) {
                    return ResultadoCombate.HUIDA;
                }
                continue;
            }
            if (respuesta.trim().isEmpty()) {
                vista.aviso(TipoAviso.INFO, "Respuesta vacía", "Escribe una respuesta para poder atacar.");
                continue;
            }

            intentos++;
            if (enemigo.validar(respuesta)) {
                atacar(enemigo, intentos, segundos);
                if (enemigo.estaDerrotado()) return ResultadoCombate.VICTORIA;
            } else {
                fallar();
            }
        }
        return ResultadoCombate.DERROTA;
    }

    private void atacar(Enemigo enemigo, int intentos, long segundos) {
        Habilidad habilidad = usuario.getMejorHabilidad();
        int danio = habilidad.calcularDanio(intentos, segundos);   // polimorfismo
        int exceso = enemigo.recibirDanio(danio);

        StringBuilder detalle = new StringBuilder();
        detalle.append("Usaste ").append(habilidad.getNombre()).append(": -").append(danio).append(" de vida.");
        String extra = habilidad.describirUltimoGolpe();
        if (!extra.isEmpty()) detalle.append("\n").append(extra);
        if (intentos == 1) detalle.append("\nRespondiste al primer intento.");

        if (enemigo.estaDerrotado()) {
            double bono = intentos == 1 ? 1.5 : 1.0;
            int bonoDanio = Math.min(exceso, 20);   // tope para que el daño extra no dispare la XP
            int xpBase = (int) Math.round((enemigo.getXpBase() + bonoDanio) * bono);
            int monedas = enemigo.getMonedasBase() + (intentos == 1 ? 5 : 0);
            otorgar(usuario, vista, "¡" + enemigo.getNombre() + " derrotado!", detalle.toString(), xpBase, monedas);
        } else {
            vista.aviso(TipoAviso.INFO, "¡Buen golpe!",
                    detalle + "\nEl enemigo sigue en pie con " + enemigo.getVida() + " de vida.");
        }
    }

    private void fallar() {
        boolean protegido = usuario.perderVida();
        String mensaje = protegido
                ? "Respuesta incorrecta, pero tu Escudo de Compilación absorbió el golpe."
                : "Respuesta incorrecta. Pierdes una vida (" + usuario.getVidas() + " restantes).";
        vista.aviso(TipoAviso.FALLO, "¡Fallaste!", mensaje);
        if (!usuario.estaVivo()) {
            vista.aviso(TipoAviso.FALLO, "Has caído", "Los bugs te derrotaron... pero puedes intentarlo de nuevo.");
        }
    }

    /** Entrega experiencia y monedas, y muestra la subida de nivel si ocurre. */
    public static void otorgar(Usuario usuario, Vista vista, String titulo, String detalle,
                               int xpBase, int monedas) {
        int xp = usuario.ganarExperiencia(xpBase);
        usuario.ganarMonedas(monedas);
        vista.recompensa(titulo, detalle, xp, monedas);
        if (usuario.subioNivel()) {
            Habilidad nueva = usuario.getHabilidadNueva();
            vista.subidaNivel(usuario.getNivel(), usuario.getTitulo(), nueva == null ? null : nueva.getNombre());
        }
    }
}
