package rpgacademico.principal;

import rpgacademico.nucleo.Juego;
import rpgacademico.vista.Colores;
import rpgacademico.vista.Consola;
import rpgacademico.vista.Iconos;
import rpgacademico.vista.Vista;
import rpgacademico.vista.VistaConsola;
import rpgacademico.vista.VistaJOptionPane;

/**
 * Punto de entrada.
 *   (sin argumentos)  menús con JOptionPane
 *   --consola         versión de terminal con colores
 *   --simple          sin emojis ni colores (si tu pantalla los muestra mal)
 */
public class Main {

    public static void main(String[] args) {
        boolean consola = false;
        boolean simple = false;
        for (String a : args) {
            if ("--consola".equals(a)) consola = true;
            if ("--simple".equals(a)) simple = true;
        }
        if (simple) {
            Colores.setActivo(false);
            Iconos.setEmojis(false);
        }

        Vista vista;
        if (consola) {
            Consola.iniciar();
            vista = new VistaConsola();
        } else {
            vista = new VistaJOptionPane();
        }
        new Juego(vista).iniciar();
    }
}
