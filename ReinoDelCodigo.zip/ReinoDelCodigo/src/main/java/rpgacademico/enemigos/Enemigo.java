package rpgacademico.enemigos;

import rpgacademico.modelo.Categoria;

/** Cada problema del juego es un enemigo. Las subclases deciden cómo se valida la respuesta. */
public abstract class Enemigo {

    public static final int VIDA_BASE = 30;

    private final String nombre;
    private final Categoria categoria;
    private final int dificultad;
    private final String pregunta;
    private final int vidaMaxima = VIDA_BASE;
    private int vida = VIDA_BASE;
    private String etiqueta = "";

    protected Enemigo(String nombre, Categoria categoria, int dificultad, String pregunta) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.dificultad = dificultad;
        this.pregunta = pregunta;
    }

    /** Resta vida y devuelve el daño sobrante (exceso) que no hizo falta. */
    public int recibirDanio(int danio) {
        int exceso = Math.max(0, danio - vida);
        vida = Math.max(0, vida - danio);
        return exceso;
    }

    public boolean estaDerrotado() { return vida == 0; }

    public void restaurar() { vida = vidaMaxima; }

    public int getXpBase() {
        switch (dificultad) {
            case 1:  return 10;
            case 2:  return 20;
            default: return 40;
        }
    }

    public int getMonedasBase() { return 5 + 5 * dificultad; }

    public String getNombre() { return nombre; }
    public Categoria getCategoria() { return categoria; }
    public int getDificultad() { return dificultad; }
    public String getPregunta() { return pregunta; }
    public int getVida() { return vida; }
    public int getVidaMaxima() { return vidaMaxima; }
    public String getEtiqueta() { return etiqueta; }
    public void setEtiqueta(String etiqueta) { this.etiqueta = etiqueta; }

    /** true si la respuesta es correcta. */
    public abstract boolean validar(String respuesta);

    /** Opciones para elegir, o null si la respuesta se escribe. */
    public abstract String[] getOpciones();

    /** Pista para la Poción de Pistas. Puede modificar las opciones visibles. */
    public abstract String darPista();

    public abstract String getRespuestaCorrecta();
}
