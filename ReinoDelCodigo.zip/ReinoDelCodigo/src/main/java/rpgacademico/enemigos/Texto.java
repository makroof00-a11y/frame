package rpgacademico.enemigos;

import java.text.Normalizer;
import java.util.Locale;

/** Utilidad para comparar respuestas sin importar mayúsculas, tildes ni espacios. */
final class Texto {

    private Texto() { }

    static String normalizar(String texto) {
        String sinTildes = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return sinTildes.toLowerCase(Locale.ROOT).replaceAll("\\s+", "");
    }
}
