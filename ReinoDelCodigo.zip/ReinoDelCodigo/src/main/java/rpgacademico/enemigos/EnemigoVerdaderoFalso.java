package rpgacademico.enemigos;

import java.util.Arrays;
import rpgacademico.modelo.Categoria;

/** Pregunta de verdadero o falso (hereda de opción múltiple con solo dos opciones). */
public class EnemigoVerdaderoFalso extends EnemigoOpcionMultiple {

    public EnemigoVerdaderoFalso(String nombre, Categoria categoria, int dificultad,
                                 String afirmacion, boolean esVerdadera) {
        super(nombre, categoria, dificultad, afirmacion,
                esVerdadera ? "Verdadero" : "Falso",
                Arrays.asList("Verdadero", "Falso"), false);
    }

    @Override
    public String darPista() {
        return "La respuesta empieza con la letra '" + getRespuestaCorrecta().charAt(0) + "'.";
    }
}
