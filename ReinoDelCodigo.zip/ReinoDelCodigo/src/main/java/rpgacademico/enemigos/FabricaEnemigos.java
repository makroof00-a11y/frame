package rpgacademico.enemigos;

import java.util.ArrayList;
import java.util.Locale;
import rpgacademico.excepciones.PreguntaInvalidaException;
import rpgacademico.modelo.Categoria;

/**
 * Convierte una línea del archivo de preguntas en el enemigo correcto (patrón Factory).
 *
 * Formato: TIPO|CATEGORIA|DIFICULTAD|NombreEnemigo|Pregunta|Respuesta|opciones (solo MULTIPLE)
 */
public final class FabricaEnemigos {

    private FabricaEnemigos() { }

    public static Enemigo desdeLinea(String linea, int numero) throws PreguntaInvalidaException {
        String[] c = linea.split("\\|", -1);
        if (c.length < 6) {
            throw error(numero, "faltan campos (se esperan al menos 6)");
        }
        String tipo = c[0].trim().toUpperCase(Locale.ROOT);

        Categoria categoria;
        try {
            categoria = Categoria.desdeTexto(c[1]);
        } catch (PreguntaInvalidaException e) {
            throw error(numero, e.getMessage());
        }

        int dificultad;
        try {
            dificultad = Integer.parseInt(c[2].trim());
        } catch (NumberFormatException e) {
            throw error(numero, "la dificultad debe ser un número (1 a 3)");
        }
        if (dificultad < 1 || dificultad > 3) {
            throw error(numero, "la dificultad debe estar entre 1 y 3");
        }

        String nombre = c[3].trim();
        String pregunta = c[4].trim();
        String respuesta = c[5].trim();
        if (nombre.isEmpty() || pregunta.isEmpty() || respuesta.isEmpty()) {
            throw error(numero, "nombre, pregunta y respuesta no pueden estar vacíos");
        }

        switch (tipo) {
            case "MULTIPLE": {
                if (c.length < 7) throw error(numero, "MULTIPLE necesita el campo de opciones");
                ArrayList<String> opciones = new ArrayList<String>();
                boolean contieneCorrecta = false;
                for (String o : c[6].split(";")) {
                    String limpia = o.trim();
                    if (limpia.isEmpty()) continue;
                    opciones.add(limpia);
                    if (Texto.normalizar(limpia).equals(Texto.normalizar(respuesta))) contieneCorrecta = true;
                }
                if (opciones.size() < 2) throw error(numero, "MULTIPLE necesita al menos 2 opciones");
                if (!contieneCorrecta) throw error(numero, "la respuesta correcta no está entre las opciones");
                return new EnemigoOpcionMultiple(nombre, categoria, dificultad, pregunta, respuesta, opciones);
            }
            case "VF": {
                boolean verdadera = "verdadero".equalsIgnoreCase(respuesta);
                if (!verdadera && !"falso".equalsIgnoreCase(respuesta)) {
                    throw error(numero, "en VF la respuesta debe ser Verdadero o Falso");
                }
                return new EnemigoVerdaderoFalso(nombre, categoria, dificultad, pregunta, verdadera);
            }
            case "SALIDA":
            case "COMPLETAR": {
                ArrayList<String> aceptadas = new ArrayList<String>();
                for (String a : respuesta.split("/")) {
                    if (!a.trim().isEmpty()) aceptadas.add(a.trim());
                }
                return new EnemigoTexto(nombre, categoria, dificultad, pregunta, aceptadas);
            }
            default:
                throw error(numero, "tipo desconocido '" + tipo + "' (usa MULTIPLE, VF, SALIDA o COMPLETAR)");
        }
    }

    private static PreguntaInvalidaException error(int numero, String detalle) {
        return new PreguntaInvalidaException("preguntas.txt, línea " + numero + ": " + detalle);
    }
}
