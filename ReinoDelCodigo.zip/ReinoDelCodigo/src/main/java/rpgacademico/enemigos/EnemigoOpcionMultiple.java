package rpgacademico.enemigos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import rpgacademico.modelo.Categoria;

/** Pregunta con opciones para elegir. */
public class EnemigoOpcionMultiple extends Enemigo {

    private static final Random AZAR = new Random();

    private final String correcta;
    private final ArrayList<String> todas = new ArrayList<String>();
    private final ArrayList<String> visibles = new ArrayList<String>();

    public EnemigoOpcionMultiple(String nombre, Categoria categoria, int dificultad,
                                 String pregunta, String correcta, List<String> opciones) {
        this(nombre, categoria, dificultad, pregunta, correcta, opciones, true);
    }

    protected EnemigoOpcionMultiple(String nombre, Categoria categoria, int dificultad,
                                    String pregunta, String correcta, List<String> opciones,
                                    boolean mezclar) {
        super(nombre, categoria, dificultad, pregunta);
        this.correcta = correcta;
        todas.addAll(opciones);
        if (mezclar) Collections.shuffle(todas, AZAR);
        visibles.addAll(todas);
    }

    @Override
    public boolean validar(String respuesta) {
        return Texto.normalizar(correcta).equals(Texto.normalizar(respuesta));
    }

    @Override
    public String[] getOpciones() { return visibles.toArray(new String[visibles.size()]); }

    /** Descarta dos opciones incorrectas. */
    @Override
    public String darPista() {
        ArrayList<String> incorrectas = new ArrayList<String>();
        for (String o : visibles) {
            if (!validar(o)) incorrectas.add(o);
        }
        if (visibles.size() <= 2 || incorrectas.isEmpty()) {
            return "Ya casi no quedan opciones. ¡Tú puedes!";
        }
        Collections.shuffle(incorrectas, AZAR);
        int quitar = Math.min(2, incorrectas.size());
        for (int i = 0; i < quitar; i++) {
            visibles.remove(incorrectas.get(i));
        }
        return "Descarté " + quitar + " opciones incorrectas.";
    }

    @Override
    public String getRespuestaCorrecta() { return correcta; }

    @Override
    public void restaurar() {
        super.restaurar();
        visibles.clear();
        visibles.addAll(todas);
    }
}
