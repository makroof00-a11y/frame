package rpgacademico.enemigos;

import java.util.ArrayList;
import java.util.List;
import rpgacademico.modelo.Categoria;

/** Pregunta cuya respuesta se escribe (predecir la salida, completar código, etc.). */
public class EnemigoTexto extends Enemigo {

    private final ArrayList<String> aceptadas = new ArrayList<String>();

    public EnemigoTexto(String nombre, Categoria categoria, int dificultad,
                        String pregunta, List<String> respuestasAceptadas) {
        super(nombre, categoria, dificultad, pregunta);
        aceptadas.addAll(respuestasAceptadas);
    }

    @Override
    public boolean validar(String respuesta) {
        String normal = Texto.normalizar(respuesta);
        for (String a : aceptadas) {
            if (Texto.normalizar(a).equals(normal)) return true;
        }
        return false;
    }

    @Override
    public String[] getOpciones() { return null; }

    @Override
    public String darPista() {
        String base = aceptadas.get(0);
        return "La respuesta empieza con '" + base.charAt(0) + "' y tiene " + base.length() + " caracteres.";
    }

    @Override
    public String getRespuestaCorrecta() { return aceptadas.get(0); }
}
