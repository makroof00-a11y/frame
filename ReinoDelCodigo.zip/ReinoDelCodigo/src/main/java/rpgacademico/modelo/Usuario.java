package rpgacademico.modelo;

import java.util.ArrayList;
import rpgacademico.excepciones.MonedasInsuficientesException;
import rpgacademico.habilidades.AtaqueCritico;
import rpgacademico.habilidades.Habilidad;
import rpgacademico.habilidades.MetodoCorrecto;
import rpgacademico.habilidades.SintaxisOptima;

/** El jugador. Tiene un Inventario y una lista de Habilidades (composición). */
public class Usuario {

    private static final int VIDAS_INICIALES = 3;

    private final String nombre;
    private int vidas = VIDAS_INICIALES;
    private int vidasMaximas = VIDAS_INICIALES;
    private int monedas = 0;
    private int experiencia = 0;
    private int nivel = 1;
    private double multiplicadorXP = 1.0;
    private boolean escudoActivo = false;
    private boolean pistaActiva = false;
    private boolean subidaPendiente = false;

    private final Inventario inventario = new Inventario();
    private final ArrayList<Habilidad> habilidades = new ArrayList<Habilidad>();

    public Usuario(String nombre) {
        this.nombre = nombre;
        habilidades.add(new MetodoCorrecto());
        habilidades.add(new SintaxisOptima());
        habilidades.add(new AtaqueCritico());
    }

    // ---------- vidas y escudo ----------

    /** Quita una vida. Devuelve true si el escudo absorbió el golpe. */
    public boolean perderVida() {
        if (escudoActivo) {
            escudoActivo = false;
            return true;
        }
        vidas = Math.max(0, vidas - 1);
        return false;
    }

    public void sanar() { if (vidas < vidasMaximas) vidas++; }

    public boolean estaVivo() { return vidas > 0; }

    /** Tras caer derrotado: vuelve con todas las vidas pero pierde la mitad de las monedas. */
    public void revivir() {
        vidas = vidasMaximas;
        monedas /= 2;
        escudoActivo = false;
        pistaActiva = false;
    }

    // ---------- monedas ----------

    public void ganarMonedas(int cantidad) { monedas += cantidad; }

    public void gastarMonedas(int cantidad) throws MonedasInsuficientesException {
        if (cantidad > monedas) {
            throw new MonedasInsuficientesException(
                    "Te faltan " + (cantidad - monedas) + " monedas (tienes " + monedas + ").");
        }
        monedas -= cantidad;
    }

    // ---------- experiencia y niveles ----------

    public int xpParaSiguienteNivel() { return nivel * 100; }

    /** Suma experiencia (aplicando el multiplicador) y devuelve la cantidad realmente ganada. */
    public int ganarExperiencia(int xpBase) {
        int xp = (int) Math.round(xpBase * multiplicadorXP);
        experiencia += xp;
        while (experiencia >= xpParaSiguienteNivel()) {
            experiencia -= xpParaSiguienteNivel();
            nivel++;
            subirDeNivel();
            subidaPendiente = true;
        }
        return xp;
    }

    private void subirDeNivel() {
        if (nivel % 3 == 0) vidasMaximas++;
        vidas = vidasMaximas;
        monedas += 20;
    }

    /** true si hubo una subida de nivel desde la última vez que se preguntó. */
    public boolean subioNivel() {
        boolean r = subidaPendiente;
        subidaPendiente = false;
        return r;
    }

    public String getTitulo() {
        if (nivel < 2) return "Novato";
        if (nivel < 4) return "Aprendiz";
        if (nivel < 6) return "Programador";
        return "Maestro del Código";
    }

    // ---------- habilidades ----------

    /** La habilidad desbloqueada con mayor nivel requerido. */
    public Habilidad getMejorHabilidad() {
        Habilidad mejor = habilidades.get(0);
        for (Habilidad h : habilidades) {
            if (h.getNivelRequerido() <= nivel && h.getNivelRequerido() >= mejor.getNivelRequerido()) {
                mejor = h;
            }
        }
        return mejor;
    }

    /** Habilidad que se desbloquea justo en el nivel actual (o null). */
    public Habilidad getHabilidadNueva() {
        for (Habilidad h : habilidades) {
            if (h.getNivelRequerido() == nivel && nivel > 1) return h;
        }
        return null;
    }

    // ---------- efectos de objetos ----------

    public void activarEscudo() { escudoActivo = true; }
    public void activarPista() { pistaActiva = true; }
    public void consumirPista() { pistaActiva = false; }
    public void setMultiplicadorXP(double m) { this.multiplicadorXP = m; }

    // ---------- carga de partida ----------

    public void restaurarEstado(int nivel, int experiencia, int vidas, int vidasMaximas,
                                int monedas, double multiplicadorXP) {
        this.nivel = nivel;
        this.experiencia = experiencia;
        this.vidasMaximas = vidasMaximas;
        this.vidas = Math.min(vidas, vidasMaximas);
        this.monedas = monedas;
        this.multiplicadorXP = multiplicadorXP;
    }

    // ---------- getters ----------

    public String getNombre() { return nombre; }
    public int getVidas() { return vidas; }
    public int getVidasMaximas() { return vidasMaximas; }
    public int getMonedas() { return monedas; }
    public int getExperiencia() { return experiencia; }
    public int getNivel() { return nivel; }
    public double getMultiplicadorXP() { return multiplicadorXP; }
    public boolean isEscudoActivo() { return escudoActivo; }
    public boolean isPistaActiva() { return pistaActiva; }
    public Inventario getInventario() { return inventario; }
}
