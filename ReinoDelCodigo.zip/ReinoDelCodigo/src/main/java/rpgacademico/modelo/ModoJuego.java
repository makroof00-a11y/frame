package rpgacademico.modelo;

/** Modos de juego: deciden qué categorías de preguntas aparecen. */
public enum ModoJuego {
    ACADEMICO("Académico", "solo preguntas de programación"),
    CULTURA("Cultura general", "todo menos programación"),
    AVENTURERO("Aventurero", "programación y cultura mezcladas");

    private final String etiqueta;
    private final String descripcion;

    ModoJuego(String etiqueta, String descripcion) {
        this.etiqueta = etiqueta;
        this.descripcion = descripcion;
    }

    public String getEtiqueta() { return etiqueta; }

    public String getDescripcion() { return descripcion; }

    public boolean acepta(Categoria categoria) {
        switch (this) {
            case ACADEMICO: return categoria.esAcademica();
            case CULTURA:   return !categoria.esAcademica();
            default:        return true;
        }
    }

    /** Textos para mostrar en un menú. */
    public static String[] textosMenu() {
        ModoJuego[] modos = values();
        String[] textos = new String[modos.length];
        for (int i = 0; i < modos.length; i++) {
            textos[i] = modos[i].etiqueta + " (" + modos[i].descripcion + ")";
        }
        return textos;
    }
}
