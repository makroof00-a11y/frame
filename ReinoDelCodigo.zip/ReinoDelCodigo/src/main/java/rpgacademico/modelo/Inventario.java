package rpgacademico.modelo;

import java.util.ArrayList;
import rpgacademico.excepciones.InventarioLlenoException;
import rpgacademico.items.ItemEquipable;

/** Lista de objetos del jugador (composición: el Usuario tiene un Inventario). */
public class Inventario {

    public static final int CAPACIDAD = 8;

    private final ArrayList<ItemEquipable> items = new ArrayList<ItemEquipable>();

    public void agregar(ItemEquipable item) throws InventarioLlenoException {
        if (estaLleno()) {
            throw new InventarioLlenoException("Tu inventario está lleno (máximo " + CAPACIDAD + " objetos).");
        }
        items.add(item);
    }

    public boolean quitar(ItemEquipable item) { return items.remove(item); }

    public ItemEquipable buscar(String id) {
        for (ItemEquipable item : items) {
            if (item.getId().equals(id)) return item;
        }
        return null;
    }

    public boolean contiene(String id) { return buscar(id) != null; }

    public boolean estaLleno() { return items.size() >= CAPACIDAD; }

    public boolean estaVacio() { return items.isEmpty(); }

    public int getCantidad() { return items.size(); }

    /** Devuelve una copia para que nadie modifique la lista original por fuera. */
    public ArrayList<ItemEquipable> getItems() { return new ArrayList<ItemEquipable>(items); }
}
