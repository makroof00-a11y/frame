package rpgacademico.modelo;

import java.util.ArrayList;
import rpgacademico.excepciones.InventarioLlenoException;
import rpgacademico.excepciones.MonedasInsuficientesException;
import rpgacademico.items.AmuletoXP;
import rpgacademico.items.EscudoCompilacion;
import rpgacademico.items.FabricaItems;
import rpgacademico.items.ItemEquipable;
import rpgacademico.items.PocionPistas;
import rpgacademico.items.PocionVida;

/** Vende objetos a cambio de monedas. */
public class Tienda {

    private final ArrayList<ItemEquipable> catalogo = new ArrayList<ItemEquipable>();

    public Tienda() {
        catalogo.add(new EscudoCompilacion());
        catalogo.add(new PocionPistas());
        catalogo.add(new PocionVida());
        catalogo.add(new AmuletoXP());
    }

    public ArrayList<ItemEquipable> getCatalogo() { return new ArrayList<ItemEquipable>(catalogo); }

    /** Compra el objeto en la posición indicada y lo guarda en el inventario. */
    public ItemEquipable comprar(Usuario usuario, int indice)
            throws MonedasInsuficientesException, InventarioLlenoException {
        ItemEquipable modelo = catalogo.get(indice);
        if (usuario.getInventario().estaLleno()) {
            throw new InventarioLlenoException("No tienes espacio: tu inventario está lleno.");
        }
        usuario.gastarMonedas(modelo.getPrecio());
        ItemEquipable nuevo = FabricaItems.crear(modelo.getId());
        usuario.getInventario().agregar(nuevo);
        return nuevo;
    }
}
