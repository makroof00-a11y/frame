package rpgacademico.modelo;

import java.text.Normalizer;
import java.util.Locale;
import rpgacademico.excepciones.PreguntaInvalidaException;

/** Categorías de las preguntas. */
public enum Categoria {
    PROGRAMACION("Programación"),
    HISTORIA("Historia"),
    GEOGRAFIA("Geografía"),
    CIENCIA("Ciencia"),
    DEPORTES("Deportes"),
    CULTURA("Cultura");

    private final String etiqueta;

    Categoria(String etiqueta) { this.etiqueta = etiqueta; }

    public String getEtiqueta() { return etiqueta; }

    public boolean esAcademica() { return this == PROGRAMACION; }

    /** Convierte el texto del archivo (sin importar tildes ni mayúsculas) en una categoría. */
    public static Categoria desdeTexto(String texto) throws PreguntaInvalidaException {
        String limpio = Normalizer.normalize(texto.trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toUpperCase(Locale.ROOT);
        for (Categoria c : values()) {
            if (c.name().equals(limpio)) return c;
        }
        throw new PreguntaInvalidaException("Categoría desconocida: '" + texto.trim() + "'");
    }
}
