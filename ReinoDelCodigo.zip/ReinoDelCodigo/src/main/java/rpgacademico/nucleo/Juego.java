package rpgacademico.nucleo;

import java.io.IOException;
import java.util.ArrayList;
import rpgacademico.excepciones.ProgresoException;
import rpgacademico.excepciones.ReinoException;
import rpgacademico.items.ItemEquipable;
import rpgacademico.modelo.ModoJuego;
import rpgacademico.modelo.Usuario;
import rpgacademico.mundo.Mapa;
import rpgacademico.mundo.ResultadoSala;
import rpgacademico.mundo.Sala;
import rpgacademico.persistencia.DatosProgreso;
import rpgacademico.persistencia.GuardadoProgreso;
import rpgacademico.persistencia.Recursos;
import rpgacademico.persistencia.RepositorioPreguntas;
import rpgacademico.vista.TipoAviso;
import rpgacademico.vista.Vista;

/** Controla el flujo del juego: menús, niveles, exploración y guardado. */
public class Juego {

    private enum ResultadoNivel { COMPLETADO, MUERTO, SALIR }

    private static final int TOTAL_NIVELES = 3;
    private static final String[] NOMBRES_NIVEL = {
        "Los Bosques de las Variables", "Las Cuevas de los Ciclos", "La Fortaleza del Polimorfismo"
    };
    private static final String[] HISTORIA_NIVEL = {
        "Un bug ancestral corrompió el bosque. Cada criatura guarda un acertijo: respóndelo bien "
            + "y tu habilidad la derrotará. Encuentra la llave, cruza la puerta sellada y vence al guardián.",
        "Bajo la montaña, los bucles nunca terminan y los ecos repiten las mismas preguntas. "
            + "Las criaturas son más astutas. Reúne monedas, compra ayuda y avanza.",
        "La última fortaleza. Aquí gobierna el Polimorfismo: nada es lo que parece. "
            + "Derrota al jefe final para restaurar la paz en el Reino del Código."
    };
    private static final String[] NOMBRES_DIR = { "Norte", "Sur", "Este", "Oeste" };
    private static final int[] DF = { -1, 1, 0, 0 };
    private static final int[] DC = { 0, 0, 1, -1 };

    private final Vista vista;
    private final RepositorioPreguntas repositorio = new RepositorioPreguntas();
    private Usuario usuario;
    private ModoJuego modo;
    private int nivelActual;

    public Juego(Vista vista) { this.vista = vista; }

    // ------------------------------------------------------------------
    // Menú principal
    // ------------------------------------------------------------------

    public void iniciar() {
        vista.bienvenida();
        try {
            repositorio.cargar("preguntas.txt");
        } catch (ReinoException e) {
            vista.aviso(TipoAviso.FALLO, "Error al cargar las preguntas", e.getMessage());
            return;
        }

        boolean salir = false;
        while (!salir) {
            int op = vista.menu("Menú principal", "¿Qué quieres hacer?",
                    new String[] { "Nueva partida", "Continuar partida", "Instrucciones", "Salir" });
            switch (op) {
                case 0:
                    if (nuevaPartida()) jugar();
                    break;
                case 1:
                    if (continuarPartida()) jugar();
                    break;
                case 2:
                    mostrarInstrucciones();
                    break;
                default:
                    salir = vista.confirmar("Salir", "¿Seguro que quieres salir del juego?");
            }
        }
        vista.aviso(TipoAviso.INFO, "Hasta pronto", "Gracias por jugar El Reino del Código.");
    }

    private void mostrarInstrucciones() {
        try {
            StringBuilder texto = new StringBuilder();
            for (String linea : Recursos.leerLineas("instrucciones.txt")) {
                texto.append(linea).append('\n');
            }
            vista.narrar("Instrucciones", texto.toString().trim());
        } catch (IOException e) {
            vista.aviso(TipoAviso.FALLO, "Instrucciones", "No se pudo leer el archivo: " + e.getMessage());
        }
    }

    private boolean nuevaPartida() {
        String nombre = null;
        while (nombre == null) {
            String entrada = vista.pedirTexto("Nueva partida", "¿Cómo te llamas, aventurero?");
            if (entrada == null) return false;                 // canceló
            entrada = entrada.trim();
            if (entrada.isEmpty() || entrada.length() > 15) {
                vista.aviso(TipoAviso.INFO, "Nombre no válido", "Escribe un nombre de 1 a 15 caracteres.");
            } else {
                nombre = entrada;
            }
        }
        int eleccion = vista.menu("Modo de juego", "Elige qué tipo de preguntas quieres enfrentar:",
                ModoJuego.textosMenu());
        if (eleccion < 0) return false;

        usuario = new Usuario(nombre);
        modo = ModoJuego.values()[eleccion];
        nivelActual = 1;
        return true;
    }

    private boolean continuarPartida() {
        if (!GuardadoProgreso.existe()) {
            vista.aviso(TipoAviso.INFO, "Continuar partida", "Todavía no hay ninguna partida guardada.");
            return false;
        }
        try {
            DatosProgreso datos = GuardadoProgreso.cargar();
            usuario = datos.getUsuario();
            modo = datos.getModo();
            nivelActual = datos.getNivelMapa();
            vista.aviso(TipoAviso.EXITO, "Partida cargada",
                    "¡Bienvenido de vuelta, " + usuario.getNombre() + "!\nContinúas en el nivel " + nivelActual + ".");
            return true;
        } catch (ProgresoException e) {
            vista.aviso(TipoAviso.FALLO, "No se pudo cargar", e.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Niveles
    // ------------------------------------------------------------------

    private void jugar() {
        vista.narrar("Comienza la aventura",
                "Bienvenido, " + usuario.getNombre() + ". El Reino del Código te necesita.");
        while (nivelActual <= TOTAL_NIVELES) {
            if (!jugarNivel(nivelActual)) return;              // volvió al menú
            nivelActual++;
            if (nivelActual <= TOTAL_NIVELES) guardar(nivelActual, true);
        }
        vista.narrar("¡VICTORIA!",
                "Derrotaste a los tres jefes y restauraste la paz en el Reino del Código.\n\n"
                + "Héroe: " + usuario.getNombre() + " (" + usuario.getTitulo() + ", nivel " + usuario.getNivel() + ")\n"
                + "Monedas: " + usuario.getMonedas() + "\n\n¡Gracias por jugar!");
    }

    /** Juega un nivel. Devuelve true si se completó, false si el jugador volvió al menú. */
    private boolean jugarNivel(int nivel) {
        vista.narrar("Nivel " + nivel + ": " + NOMBRES_NIVEL[nivel - 1], HISTORIA_NIVEL[nivel - 1]);
        while (true) {
            Mapa mapa;
            try {
                mapa = Mapa.cargar("nivel" + nivel + ".txt", repositorio, nivel, modo);
            } catch (ReinoException e) {
                vista.aviso(TipoAviso.FALLO, "Error en el nivel " + nivel, e.getMessage());
                return false;
            }
            ResultadoNivel resultado = explorar(mapa, nivel);
            if (resultado == ResultadoNivel.COMPLETADO) {
                vista.aviso(TipoAviso.EXITO, "¡Nivel completado!",
                        "Superaste " + NOMBRES_NIVEL[nivel - 1] + ".");
                return true;
            }
            if (resultado == ResultadoNivel.SALIR) return false;

            // MUERTO: vuelve a empezar el nivel con vidas completas
            usuario.revivir();
            vista.aviso(TipoAviso.INFO, "Vuelves a levantarte",
                    "Recuperas todas tus vidas pero pierdes la mitad de tus monedas.\n"
                    + "El nivel se reinicia con preguntas nuevas.");
        }
    }

    private ResultadoNivel explorar(Mapa mapa, int nivel) {
        int fila = mapa.getInicioFila();
        int col = mapa.getInicioColumna();
        mapa.getSala(fila, col).marcarVisitada();

        while (true) {
            Sala actual = mapa.getSala(fila, col);
            ArrayList<Integer> direcciones = new ArrayList<Integer>();
            ArrayList<String> opciones = new ArrayList<String>();
            for (int d = 0; d < NOMBRES_DIR.length; d++) {
                Sala vecina = mapa.getSala(fila + DF[d], col + DC[d]);
                if (vecina != null) {
                    direcciones.add(d);
                    opciones.add("Ir al " + NOMBRES_DIR[d] + " — "
                            + (vecina.isVisitada() ? vecina.getNombre() : "sin explorar"));
                }
            }
            int movimientos = opciones.size();
            opciones.add("Inventario");
            opciones.add("Estado del héroe");
            opciones.add("Guardar partida");
            opciones.add("Salir al menú principal");

            int op = vista.menuExploracion(usuario,
                    "Nivel " + nivel + " · " + NOMBRES_NIVEL[nivel - 1],
                    actual.getNombre(), actual.getDescripcion(), mapa.dibujar(fila, col),
                    opciones.toArray(new String[opciones.size()]));
            if (op < 0) op = opciones.size() - 1;              // cerrar la ventana = intentar salir

            if (op < movimientos) {
                int d = direcciones.get(op);
                int nf = fila + DF[d];
                int nc = col + DC[d];
                Sala destino = mapa.getSala(nf, nc);
                if (!destino.puedeEntrar(usuario, vista)) continue;

                int antesF = fila;
                int antesC = col;
                fila = nf;
                col = nc;
                destino.marcarVisitada();
                ResultadoSala r = destino.entrar(usuario, vista);
                if (r == ResultadoSala.RETROCEDER) {
                    fila = antesF;
                    col = antesC;
                } else if (r == ResultadoSala.JUGADOR_MUERTO) {
                    return ResultadoNivel.MUERTO;
                } else if (r == ResultadoSala.NIVEL_COMPLETADO) {
                    return ResultadoNivel.COMPLETADO;
                }
            } else {
                switch (op - movimientos) {
                    case 0: gestionarInventario(); break;
                    case 1: vista.estado(usuario); break;
                    case 2: guardar(nivel, false); break;
                    default:
                        if (vista.confirmar("Salir", "¿Volver al menú principal?\n"
                                + "(Se pierde el progreso del nivel que no hayas guardado)")) {
                            return ResultadoNivel.SALIR;
                        }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Inventario y guardado
    // ------------------------------------------------------------------

    private void gestionarInventario() {
        boolean volver = false;
        while (!volver) {
            ArrayList<ItemEquipable> items = usuario.getInventario().getItems();
            if (items.isEmpty()) {
                vista.aviso(TipoAviso.INFO, "Inventario", "Tu inventario está vacío. Visita la tienda o abre cofres.");
                return;
            }
            String[] opciones = new String[items.size() + 1];
            for (int i = 0; i < items.size(); i++) {
                opciones[i] = items.get(i).getNombre() + " — " + items.get(i).getDescripcion();
            }
            opciones[items.size()] = "Volver";

            int eleccion = vista.menu("Inventario",
                    "Objetos: " + items.size() + "/8. Elige uno para usarlo.", opciones);
            if (eleccion < 0 || eleccion == items.size()) {
                volver = true;
            } else {
                ItemEquipable item = items.get(eleccion);
                if (!item.puedeUsarse(usuario)) {
                    vista.aviso(TipoAviso.INFO, item.getNombre(), "Ahora mismo no puedes usar este objeto.");
                } else {
                    String mensaje = item.usar(usuario);
                    if (item.esConsumible()) usuario.getInventario().quitar(item);
                    vista.aviso(TipoAviso.EXITO, item.getNombre(), mensaje);
                }
            }
        }
    }

    private void guardar(int nivel, boolean silencioso) {
        try {
            GuardadoProgreso.guardar(usuario, modo, nivel);
            if (!silencioso) {
                vista.aviso(TipoAviso.EXITO, "Partida guardada",
                        "Progreso guardado. Al continuar empezarás el nivel " + nivel + " desde su inicio.");
            }
        } catch (ProgresoException e) {
            vista.aviso(TipoAviso.FALLO, "No se pudo guardar", e.getMessage());
        }
    }
}
