package rpgacademico.mundo;

import java.util.ArrayList;
import java.util.Random;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.excepciones.MapaInvalidoException;
import rpgacademico.excepciones.PreguntaInvalidaException;
import rpgacademico.modelo.ModoJuego;
import rpgacademico.persistencia.RepositorioPreguntas;

/** Crea la sala que corresponde a cada carácter del archivo de mapa (patrón Factory). */
public final class FabricaSalas {

    private static final Random AZAR = new Random();
    private static final String[][] SENDEROS = {
        { "Sendero de piedra", "Un camino tranquilo. El aire huele a café y a código recién compilado." },
        { "Claro silencioso", "Un claro donde solo se oye el zumbido lejano de un ventilador." },
        { "Puente de cuerda", "Un puente crujiente cruza un abismo lleno de mensajes de error." },
        { "Pasillo de luciérnagas", "Cientos de luces diminutas parpadean como cursores en la oscuridad." }
    };
    private static final int FASES_JEFE = 3;

    private FabricaSalas() { }

    public static Sala crear(char c, RepositorioPreguntas repo, int nivel, ModoJuego modo)
            throws MapaInvalidoException, PreguntaInvalidaException {
        switch (c) {
            case 'S':
                return new SalaVacia('S', "Punto de inicio", "Aquí comienza tu aventura en este nivel.");
            case '.': {
                String[] s = SENDEROS[AZAR.nextInt(SENDEROS.length)];
                return new SalaVacia('.', s[0], s[1]);
            }
            case 'E': {
                ArrayList<Enemigo> uno = new ArrayList<Enemigo>();
                uno.add(repo.siguiente(nivel, modo));
                return new SalaCombate('E', uno);
            }
            case 'J': {
                ArrayList<Enemigo> fases = new ArrayList<Enemigo>();
                for (int i = 0; i < FASES_JEFE; i++) fases.add(repo.siguiente(nivel, modo));
                return new SalaJefe(fases);
            }
            case 'T': return new SalaTienda();
            case 'C': return new SalaTesoro('C', false);
            case 'K': return new SalaTesoro('K', true);
            case 'L': return new SalaBloqueada();
            default:
                throw new MapaInvalidoException("Carácter desconocido en el mapa: '" + c + "'");
        }
    }
}
