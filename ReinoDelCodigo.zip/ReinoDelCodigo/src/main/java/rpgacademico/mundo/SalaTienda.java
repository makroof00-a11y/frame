package rpgacademico.mundo;

import java.util.ArrayList;
import rpgacademico.excepciones.InventarioLlenoException;
import rpgacademico.excepciones.MonedasInsuficientesException;
import rpgacademico.items.ItemEquipable;
import rpgacademico.modelo.Tienda;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.TipoAviso;
import rpgacademico.vista.Vista;

/** El mercader: aquí se gastan las monedas. */
public class SalaTienda extends Sala {

    private final Tienda tienda = new Tienda();

    public SalaTienda() { super('T'); }

    @Override public String getNombre() { return "Tienda del Mercader"; }

    @Override public String getDescripcion() { return "Un mercader ofrece objetos útiles a cambio de monedas."; }

    @Override public char getSimboloMapa() { return 'T'; }

    @Override
    public ResultadoSala entrar(Usuario usuario, Vista vista) {
        boolean salir = false;
        while (!salir) {
            ArrayList<ItemEquipable> catalogo = tienda.getCatalogo();
            String[] opciones = new String[catalogo.size() + 1];
            StringBuilder encabezado = new StringBuilder("Tienes " + usuario.getMonedas() + " monedas.\n");
            for (int i = 0; i < catalogo.size(); i++) {
                ItemEquipable item = catalogo.get(i);
                opciones[i] = item.getNombre() + " — " + item.getPrecio() + " monedas";
                encabezado.append("\n• ").append(item.getNombre()).append(": ").append(item.getDescripcion());
            }
            opciones[catalogo.size()] = "Salir de la tienda";

            int eleccion = vista.menu("Tienda del Mercader", encabezado.toString(), opciones);
            if (eleccion < 0 || eleccion == catalogo.size()) {
                salir = true;
            } else {
                try {
                    ItemEquipable comprado = tienda.comprar(usuario, eleccion);
                    vista.aviso(TipoAviso.EXITO, "Compra realizada",
                            "Compraste: " + comprado.getNombre() + "\n" + comprado.getDescripcion());
                } catch (MonedasInsuficientesException | InventarioLlenoException e) {
                    vista.aviso(TipoAviso.FALLO, "No se pudo comprar", e.getMessage());
                }
            }
        }
        return ResultadoSala.OK;
    }
}
