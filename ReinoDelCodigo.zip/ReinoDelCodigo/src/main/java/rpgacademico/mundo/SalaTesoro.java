package rpgacademico.mundo;

import java.util.Random;
import rpgacademico.excepciones.InventarioLlenoException;
import rpgacademico.items.FabricaItems;
import rpgacademico.items.ItemEquipable;
import rpgacademico.items.LlaveCompilacion;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.TipoAviso;
import rpgacademico.vista.Vista;

/** Cofre con monedas y, a veces, un objeto. El cofre especial guarda la llave de la puerta sellada. */
public class SalaTesoro extends Sala {

    private final boolean conLlave;
    private final Random azar = new Random();

    public SalaTesoro(char simbolo, boolean conLlave) {
        super(simbolo);
        this.conLlave = conLlave;
    }

    @Override public String getNombre() { return isCompletada() ? "Cofre vacío" : "Sala del cofre"; }

    @Override
    public String getDescripcion() {
        return isCompletada() ? "Ya te llevaste todo lo que había."
                : "Un cofre antiguo brilla en el centro de la sala.";
    }

    @Override
    public ResultadoSala entrar(Usuario usuario, Vista vista) {
        if (isCompletada()) return ResultadoSala.OK;

        ItemEquipable premio = conLlave ? new LlaveCompilacion()
                : (azar.nextBoolean() ? FabricaItems.aleatorio(azar) : null);
        int monedas = 20 + azar.nextInt(21);
        try {
            if (premio != null) usuario.getInventario().agregar(premio);
        } catch (InventarioLlenoException e) {
            vista.aviso(TipoAviso.FALLO, "Cofre",
                    e.getMessage() + "\nUsa o guarda espacio y vuelve por el contenido del cofre.");
            return ResultadoSala.OK;
        }
        usuario.ganarMonedas(monedas);
        marcarCompletada();

        String texto = "Encontraste " + monedas + " monedas.";
        if (premio != null) texto += "\nY también: " + premio.getNombre() + ".";
        vista.aviso(TipoAviso.EXITO, "¡Cofre abierto!", texto);
        return ResultadoSala.OK;
    }
}
