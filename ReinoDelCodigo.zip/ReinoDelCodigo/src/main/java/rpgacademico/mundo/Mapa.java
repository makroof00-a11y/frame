package rpgacademico.mundo;

import java.io.IOException;
import java.util.ArrayList;
import rpgacademico.excepciones.MapaInvalidoException;
import rpgacademico.excepciones.PreguntaInvalidaException;
import rpgacademico.modelo.ModoJuego;
import rpgacademico.persistencia.RepositorioPreguntas;
import rpgacademico.persistencia.Recursos;

/**
 * Mapa de un nivel, leído desde un archivo de texto.
 * '#' pared, 'S' inicio, '.' camino, 'E' enemigo, 'T' tienda, 'C' cofre,
 * 'K' cofre con llave, 'L' puerta sellada, 'J' jefe.
 */
public class Mapa {

    private final Sala[][] salas;
    private final int inicioFila;
    private final int inicioColumna;

    private Mapa(Sala[][] salas, int inicioFila, int inicioColumna) {
        this.salas = salas;
        this.inicioFila = inicioFila;
        this.inicioColumna = inicioColumna;
    }

    public static Mapa cargar(String archivo, RepositorioPreguntas repo, int nivel, ModoJuego modo)
            throws MapaInvalidoException, PreguntaInvalidaException {
        ArrayList<String> lineas = new ArrayList<String>();
        try {
            for (String l : Recursos.leerLineas(archivo)) {
                if (!l.trim().isEmpty()) lineas.add(l.replaceAll("\\s+$", ""));
            }
        } catch (IOException e) {
            throw new MapaInvalidoException("No se pudo leer el mapa " + archivo + ": " + e.getMessage(), e);
        }
        if (lineas.size() < 3) {
            throw new MapaInvalidoException("El mapa " + archivo + " es demasiado pequeño.");
        }

        int ancho = lineas.get(0).length();
        Sala[][] salas = new Sala[lineas.size()][ancho];
        int inicios = 0, jefes = 0, filaInicio = -1, colInicio = -1;

        for (int f = 0; f < lineas.size(); f++) {
            String linea = lineas.get(f);
            if (linea.length() != ancho) {
                throw new MapaInvalidoException("Mapa " + archivo + ": la línea " + (f + 1)
                        + " mide " + linea.length() + " y debería medir " + ancho + ".");
            }
            for (int c = 0; c < ancho; c++) {
                char ch = linea.charAt(c);
                if (ch == '#') continue;                       // pared: no hay sala
                salas[f][c] = FabricaSalas.crear(ch, repo, nivel, modo);
                if (ch == 'S') { inicios++; filaInicio = f; colInicio = c; }
                if (ch == 'J') jefes++;
            }
        }
        if (inicios != 1) throw new MapaInvalidoException("El mapa " + archivo + " debe tener exactamente una 'S'.");
        if (jefes != 1) throw new MapaInvalidoException("El mapa " + archivo + " debe tener exactamente una 'J'.");
        return new Mapa(salas, filaInicio, colInicio);
    }

    /** Sala en esa posición, o null si es pared o está fuera del mapa. */
    public Sala getSala(int fila, int columna) {
        if (fila < 0 || fila >= salas.length || columna < 0 || columna >= salas[fila].length) return null;
        return salas[fila][columna];
    }

    public int getInicioFila() { return inicioFila; }

    public int getInicioColumna() { return inicioColumna; }

    /** Dibuja el minimapa: @ eres tú, ? sin explorar, ▒ pared. */
    public String dibujar(int filaJugador, int colJugador) {
        StringBuilder sb = new StringBuilder();
        for (int f = 0; f < salas.length; f++) {
            for (int c = 0; c < salas[f].length; c++) {
                Sala s = salas[f][c];
                if (f == filaJugador && c == colJugador) sb.append('@');
                else if (s == null) sb.append('▒');
                else if (!s.isVisitada()) sb.append('?');
                else sb.append(s.getSimboloMapa());
            }
            if (f < salas.length - 1) sb.append('\n');
        }
        return sb.toString();
    }
}
