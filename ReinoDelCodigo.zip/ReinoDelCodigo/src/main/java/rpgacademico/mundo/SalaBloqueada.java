package rpgacademico.mundo;

import rpgacademico.items.ItemEquipable;
import rpgacademico.items.LlaveCompilacion;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.TipoAviso;
import rpgacademico.vista.Vista;

/** Puerta sellada: solo se cruza con la Llave de Compilación. */
public class SalaBloqueada extends Sala {

    private boolean abierta = false;

    public SalaBloqueada() { super('L'); }

    @Override public String getNombre() { return abierta ? "Puerta abierta" : "Puerta sellada"; }

    @Override
    public String getDescripcion() {
        return abierta ? "La puerta ya está abierta. El camino sigue."
                : "Una puerta sellada bloquea el paso. Necesitas una llave.";
    }

    @Override public char getSimboloMapa() { return abierta ? '·' : 'L'; }

    @Override
    public boolean puedeEntrar(Usuario usuario, Vista vista) {
        if (abierta) return true;
        ItemEquipable llave = usuario.getInventario().buscar(LlaveCompilacion.ID);
        if (llave == null) {
            vista.aviso(TipoAviso.FALLO, "Puerta sellada",
                    "La puerta no se mueve. Busca la Llave de Compilación en algún cofre.");
            return false;
        }
        usuario.getInventario().quitar(llave);
        abierta = true;
        vista.aviso(TipoAviso.EXITO, "¡Puerta abierta!", "Usaste la Llave de Compilación. El camino está libre.");
        return true;
    }

    @Override
    public ResultadoSala entrar(Usuario usuario, Vista vista) { return ResultadoSala.OK; }
}
