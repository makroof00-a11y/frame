package rpgacademico.mundo;

import rpgacademico.modelo.Usuario;
import rpgacademico.vista.Vista;

/** Clase abstracta: cada tipo de sala reacciona distinto cuando el jugador entra (polimorfismo). */
public abstract class Sala {

    private final char simbolo;
    private boolean visitada = false;
    private boolean completada = false;

    protected Sala(char simbolo) { this.simbolo = simbolo; }

    public abstract String getNombre();

    public abstract String getDescripcion();

    /** Se llama al intentar entrar. Una puerta sellada puede negar el paso. */
    public boolean puedeEntrar(Usuario usuario, Vista vista) { return true; }

    /** Lo que ocurre al entrar a la sala. */
    public abstract ResultadoSala entrar(Usuario usuario, Vista vista);

    /** Carácter que se dibuja en el minimapa. */
    public char getSimboloMapa() { return completada ? '·' : simbolo; }

    public boolean isVisitada() { return visitada; }
    public void marcarVisitada() { visitada = true; }
    public boolean isCompletada() { return completada; }
    protected void marcarCompletada() { completada = true; }
}
