package rpgacademico.mundo;

/** Qué pasó al entrar a una sala. */
public enum ResultadoSala { OK, RETROCEDER, JUGADOR_MUERTO, NIVEL_COMPLETADO }
