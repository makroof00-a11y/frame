package rpgacademico.mundo;

import rpgacademico.modelo.Usuario;
import rpgacademico.vista.Vista;

/** Sala tranquila: sirve como camino o como punto de inicio. */
public class SalaVacia extends Sala {

    private final String nombre;
    private final String descripcion;

    public SalaVacia(char simbolo, String nombre, String descripcion) {
        super(simbolo);
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    @Override public String getNombre() { return nombre; }

    @Override public String getDescripcion() { return descripcion; }

    @Override public char getSimboloMapa() { return isVisitada() ? '·' : '.'; }

    @Override
    public ResultadoSala entrar(Usuario usuario, Vista vista) { return ResultadoSala.OK; }
}
