package rpgacademico.mundo;

import java.util.ArrayList;
import rpgacademico.combate.Combate;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.Vista;

/** Sala del jefe del nivel: varias fases (varias preguntas) y una gran recompensa. */
public class SalaJefe extends SalaCombate {

    public SalaJefe(ArrayList<Enemigo> fases) {
        super('J', fases);
        for (int i = 0; i < fases.size(); i++) {
            fases.get(i).setEtiqueta("[JEFE · fase " + (i + 1) + "/" + fases.size() + "] ");
        }
    }

    @Override
    public String getNombre() { return isCompletada() ? "Guarida vacía" : "Guarida del Jefe"; }

    @Override
    public String getDescripcion() {
        return isCompletada() ? "El jefe ya fue derrotado."
                : "Un jefe te espera con " + enemigos.size() + " fases. ¡Prepárate!";
    }

    @Override
    protected ResultadoSala alVencer(Usuario usuario, Vista vista) {
        Combate.otorgar(usuario, vista, "¡JEFE DERROTADO!",
                "Has limpiado el nivel de bugs.", 100, 50);
        return ResultadoSala.NIVEL_COMPLETADO;
    }
}
