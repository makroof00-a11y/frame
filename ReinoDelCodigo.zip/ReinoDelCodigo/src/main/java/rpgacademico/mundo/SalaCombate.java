package rpgacademico.mundo;

import java.util.ArrayList;
import rpgacademico.combate.Combate;
import rpgacademico.combate.ResultadoCombate;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.modelo.Usuario;
import rpgacademico.vista.Vista;

/** Sala con uno o más enemigos que hay que vencer para poder pasar. */
public class SalaCombate extends Sala {

    protected final ArrayList<Enemigo> enemigos;

    public SalaCombate(char simbolo, ArrayList<Enemigo> enemigos) {
        super(simbolo);
        this.enemigos = enemigos;
    }

    @Override
    public String getNombre() { return isCompletada() ? "Sala despejada" : "Sala de combate"; }

    @Override
    public String getDescripcion() {
        if (isCompletada()) return "Los bugs de aquí ya fueron derrotados.";
        return "Algo se mueve entre las sombras. Quedan " + enemigos.size() + " enemigo(s).";
    }

    @Override
    public ResultadoSala entrar(Usuario usuario, Vista vista) {
        if (isCompletada()) return ResultadoSala.OK;

        Combate combate = new Combate(usuario, vista);
        while (!enemigos.isEmpty()) {
            ResultadoCombate resultado = combate.pelear(enemigos.get(0));
            if (resultado == ResultadoCombate.VICTORIA) {
                enemigos.remove(0);
            } else if (resultado == ResultadoCombate.HUIDA) {
                return ResultadoSala.RETROCEDER;
            } else {
                return ResultadoSala.JUGADOR_MUERTO;
            }
        }
        marcarCompletada();
        return alVencer(usuario, vista);
    }

    /** Gancho para que las subclases añadan recompensas al vencer a todos. */
    protected ResultadoSala alVencer(Usuario usuario, Vista vista) { return ResultadoSala.OK; }
}
