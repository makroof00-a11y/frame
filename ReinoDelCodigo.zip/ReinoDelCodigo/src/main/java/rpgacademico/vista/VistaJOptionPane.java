package rpgacademico.vista;

import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.items.ItemEquipable;
import rpgacademico.modelo.Usuario;

/** Interfaz con ventanas JOptionPane: menús, botones y cuadros de texto con formato HTML. */
public class VistaJOptionPane implements Vista {

    private static final int ANCHO = 420;
    private static final String DORADO = "#B8860B";
    private static final String VERDE = "#1E8449";
    private static final String ROJO = "#C0392B";
    private static final String AZUL = "#2471A3";
    private static final String MORADO = "#6C3483";
    private static final String GRIS = "#7F8C8D";

    public VistaJOptionPane() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Si falla, se usa el aspecto por defecto de Java
        }
        UIManager.put("OptionPane.messageFont", new Font("SansSerif", Font.PLAIN, 13));
        UIManager.put("OptionPane.buttonFont", new Font("SansSerif", Font.PLAIN, 13));
    }

    // ------------------------------------------------------------------
    // Utilidades HTML
    // ------------------------------------------------------------------

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }

    private static String color(String texto, String hex) {
        return "<font color='" + hex + "'>" + texto + "</font>";
    }

    private static String html(String cuerpo) {
        return "<html><body style='width:" + ANCHO + "px'>" + cuerpo + "</body></html>";
    }

    private static String repetir(String s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(s);
        return sb.toString();
    }

    private static String barra(int actual, int max, int largo, String hex) {
        int llenos = max <= 0 ? 0 : Math.min(largo, Math.max(0, actual * largo / max));
        return color(repetir("█", llenos), hex) + color(repetir("░", largo - llenos), GRIS);
    }

    private static String corazones(Usuario u) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < u.getVidasMaximas(); i++) {
            sb.append(i < u.getVidas() ? Iconos.corazon() : color("·", GRIS)).append(' ');
        }
        return sb.toString().trim();
    }

    private static String linea(Usuario u) {
        return corazones(u) + " &nbsp; " + Iconos.moneda() + " " + u.getMonedas()
                + " &nbsp; " + Iconos.estrella() + " Nv " + u.getNivel() + " "
                + barra(u.getExperiencia(), u.xpParaSiguienteNivel(), 12, VERDE)
                + " " + u.getExperiencia() + "/" + u.xpParaSiguienteNivel();
    }

    /** Menú con botones (hasta 4 opciones) o lista desplegable (más de 4). */
    private int elegir(String titulo, String cuerpoHtml, String[] opciones) {
        String mensaje = html(cuerpoHtml);
        if (opciones.length <= 4) {
            return JOptionPane.showOptionDialog(null, mensaje, titulo, JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
        }
        Object elegido = JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.PLAIN_MESSAGE,
                null, opciones, opciones[0]);
        if (elegido == null) return -1;
        for (int i = 0; i < opciones.length; i++) {
            if (opciones[i].equals(elegido)) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------------
    // Vista
    // ------------------------------------------------------------------

    @Override
    public void bienvenida() {
        String cuerpo = "<div style='text-align:center'><h1>" + Iconos.castillo() + "<br>"
                + color("EL REINO DEL CÓDIGO", DORADO) + "</h1>"
                + "<i>Aprende, combate y sube de nivel</i></div>";
        JOptionPane.showMessageDialog(null, html(cuerpo), "El Reino del Código", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public void narrar(String titulo, String texto) {
        String cuerpo = "<b><font size='+1'>" + Iconos.libro() + " " + esc(titulo) + "</font></b><hr><i>"
                + esc(texto) + "</i>";
        JOptionPane.showMessageDialog(null, html(cuerpo), titulo, JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public int menu(String titulo, String encabezado, String[] opciones) {
        String cuerpo = "<b><font size='+1'>" + esc(titulo) + "</font></b>";
        if (encabezado != null && !encabezado.isEmpty()) cuerpo += "<br>" + esc(encabezado);
        return elegir(titulo, cuerpo, opciones);
    }

    @Override
    public String pedirTexto(String titulo, String pregunta) {
        return JOptionPane.showInputDialog(null, html(esc(pregunta)), titulo, JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public boolean confirmar(String titulo, String pregunta) {
        int r = JOptionPane.showConfirmDialog(null, html(esc(pregunta)), titulo,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return r == JOptionPane.YES_OPTION;
    }

    @Override
    public void aviso(TipoAviso tipo, String titulo, String texto) {
        String icono;
        String hex;
        switch (tipo) {
            case EXITO: icono = Iconos.correcto(); hex = VERDE; break;
            case FALLO: icono = Iconos.error();    hex = ROJO;  break;
            default:    icono = Iconos.libro();    hex = AZUL;  break;
        }
        String cuerpo = "<b><font size='+1'>" + icono + " " + color(esc(titulo), hex) + "</font></b><br>" + esc(texto);
        JOptionPane.showMessageDialog(null, html(cuerpo), titulo, JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public void recompensa(String titulo, String detalle, int xp, int monedas) {
        String cuerpo = "<b><font size='+1'>" + Iconos.correcto() + " " + color(esc(titulo), VERDE) + "</font></b><br>"
                + esc(detalle) + "<br><br>"
                + Iconos.estrella() + " <b>" + color("+" + xp + " XP", VERDE) + "</b> &nbsp; "
                + Iconos.moneda() + " <b>" + color("+" + monedas, DORADO) + "</b>";
        JOptionPane.showMessageDialog(null, html(cuerpo), "Victoria", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public void subidaNivel(int nivel, String titulo, String desbloqueo) {
        String cuerpo = "<div style='text-align:center'><h2>" + Iconos.fiesta() + " "
                + color("¡SUBISTE DE NIVEL!", DORADO) + " " + Iconos.fiesta() + "</h2>"
                + "Ahora eres <b>Nivel " + nivel + "</b> · " + color(esc(titulo), MORADO)
                + "<br>Vidas restauradas y +20 monedas de regalo.";
        if (desbloqueo != null) {
            cuerpo += "<br><br>" + Iconos.rayo() + " Habilidad desbloqueada: <b>" + esc(desbloqueo) + "</b>";
        }
        cuerpo += "</div>";
        JOptionPane.showMessageDialog(null, html(cuerpo), "¡Nivel " + nivel + "!", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public void estado(Usuario u) {
        StringBuilder sb = new StringBuilder();
        sb.append("<b><font size='+1'>").append(Iconos.castillo()).append(" ").append(esc(u.getNombre()))
                .append("</font></b> · ").append(color(esc(u.getTitulo()), MORADO)).append("<hr>");
        sb.append(linea(u)).append("<br><br>");
        sb.append("Habilidad actual: <b>").append(esc(u.getMejorHabilidad().getNombre())).append("</b><br>")
                .append("<i>").append(esc(u.getMejorHabilidad().getDescripcion())).append("</i><br>");
        sb.append("Multiplicador de XP: x").append(u.getMultiplicadorXP()).append("<br>");
        if (u.isEscudoActivo()) sb.append(Iconos.escudo()).append(" Escudo activo<br>");
        if (u.isPistaActiva()) sb.append(Iconos.bombilla()).append(" Pista preparada<br>");
        sb.append("<br><b>Inventario (").append(u.getInventario().getCantidad()).append("/8)</b><br>");
        if (u.getInventario().estaVacio()) {
            sb.append("<i>vacío</i>");
        } else {
            for (ItemEquipable item : u.getInventario().getItems()) {
                sb.append("• ").append(esc(item.getNombre())).append("<br>");
            }
        }
        JOptionPane.showMessageDialog(null, html(sb.toString()), "Estado del héroe", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public String preguntar(Enemigo e, Usuario u, String pista) {
        String icono = e.getEtiqueta().isEmpty() ? Iconos.espadas() : Iconos.corona();
        StringBuilder sb = new StringBuilder();
        sb.append("<b><font size='+1'>").append(icono).append(" ").append(esc(e.getEtiqueta() + e.getNombre()))
                .append("</font></b><br>");
        sb.append(color(esc(e.getCategoria().getEtiqueta()), AZUL)).append(" · Dificultad ").append(e.getDificultad()).append("<br>");
        sb.append("Enemigo ").append(barra(e.getVida(), e.getVidaMaxima(), 20, ROJO)).append(" ")
                .append(e.getVida()).append("/").append(e.getVidaMaxima()).append("<br>");
        sb.append("Tú &nbsp;&nbsp;&nbsp;&nbsp; ").append(linea(u)).append("<hr>");
        sb.append("<b>").append(esc(e.getPregunta())).append("</b>");
        if (pista != null) {
            sb.append("<br><br>").append(Iconos.bombilla()).append(" <i>").append(esc(pista)).append("</i>");
        }

        String[] opciones = e.getOpciones();
        if (opciones != null) {
            sb.append("<br><br><font color='").append(GRIS).append("'><i>Elige una opción (cerrar la ventana = huir)</i></font>");
            int idx = JOptionPane.showOptionDialog(null, html(sb.toString()), "Combate",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, null);
            return idx < 0 ? null : opciones[idx];
        }
        sb.append("<br><br><font color='").append(GRIS).append("'><i>Escribe tu respuesta (Cancelar = huir)</i></font>");
        return JOptionPane.showInputDialog(null, html(sb.toString()), "Combate", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    public int menuExploracion(Usuario u, String nivel, String lugar, String descripcion,
                               String minimapa, String[] opciones) {
        StringBuilder sb = new StringBuilder();
        sb.append("<b>").append(Iconos.castillo()).append(" ").append(esc(u.getNombre())).append("</b> · ")
                .append(color(esc(u.getTitulo()), MORADO)).append(" · ").append(color(esc(nivel), DORADO)).append("<br>");
        sb.append(linea(u)).append("<hr>");
        sb.append("<b>").append(Iconos.mapa()).append(" ").append(esc(lugar)).append("</b><br>");
        sb.append("<i>").append(esc(descripcion)).append("</i><br>");
        sb.append("<pre style='font-family:monospaced'>").append(esc(minimapa)).append("</pre>");
        sb.append("<font color='").append(GRIS).append("'>@ tú · ? sin explorar · E enemigo · T tienda · K/C cofre · L puerta · J jefe</font>");
        return elegir("Exploración", sb.toString(), opciones);
    }
}
