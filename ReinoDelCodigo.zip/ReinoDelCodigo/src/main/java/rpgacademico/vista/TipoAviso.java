package rpgacademico.vista;

/** Tipo de mensaje que se le muestra al jugador. */
public enum TipoAviso { EXITO, FALLO, INFO }
