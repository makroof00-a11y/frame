package rpgacademico.vista;

/**
 * Emojis del juego. Si la terminal no los muestra bien,
 * llama a Iconos.setEmojis(false) y se usan símbolos simples.
 */
public final class Iconos {

    private static boolean emojis = true;

    private Iconos() { }

    public static void setEmojis(boolean valor) { emojis = valor; }

    private static String i(String emoji, String simple) {
        return emojis ? emoji : simple;
    }

    public static String castillo()  { return i("🏰", "[#]"); }
    public static String espadas()   { return i("⚔️", "[x]"); }
    public static String escudo()    { return i("🛡️", "[o]"); }
    public static String corazon()   { return i("❤️", "<3"); }
    public static String moneda()    { return i("🪙", "$"); }
    public static String estrella()  { return i("⭐", "*"); }
    public static String bug()       { return i("🐛", "(b)"); }
    public static String corona()    { return i("👑", "(K)"); }
    public static String pocion()    { return i("🧪", "(p)"); }
    public static String llave()     { return i("🗝️", "(k)"); }
    public static String bombilla()  { return i("💡", "(?)"); }
    public static String correcto()  { return i("✅", "[OK]"); }
    public static String error()     { return i("❌", "[X]"); }
    public static String fiesta()    { return i("🎉", "!!"); }
    public static String cofre()     { return i("🎁", "[+]"); }
    public static String tienda()    { return i("🛒", "[T]"); }
    public static String mapa()      { return i("🧭", ">"); }
    public static String libro()     { return i("📜", "~"); }
    public static String calavera()  { return i("💀", "x_x"); }
    public static String rayo()      { return i("⚡", "!"); }
}
