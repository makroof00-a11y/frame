package rpgacademico.vista;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.items.ItemEquipable;
import rpgacademico.modelo.Usuario;

/** Interfaz de terminal con colores y cajas (se activa con el argumento --consola). */
public class VistaConsola implements Vista {

    private final BufferedReader entrada =
            new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

    private String leer() {
        try {
            String linea = entrada.readLine();
            if (linea == null) {          // se cerró la entrada: terminar limpiamente
                System.out.println();
                System.exit(0);
            }
            return linea;
        } catch (IOException e) {
            System.exit(1);
            return null;
        }
    }

    private void pausa() {
        System.out.print(Colores.tenue("   (ENTER para continuar) "));
        leer();
    }

    private static ArrayList<String> lineas(String texto) {
        return new ArrayList<String>(Arrays.asList(texto.split("\n", -1)));
    }

    @Override
    public void bienvenida() {
        Consola.banner();
        System.out.println();
    }

    @Override
    public void narrar(String titulo, String texto) {
        System.out.println();
        Consola.cuadro(Iconos.libro() + " " + titulo, Colores.MORADO, lineas(texto), false);
        pausa();
    }

    @Override
    public int menu(String titulo, String encabezado, String[] opciones) {
        System.out.println();
        ArrayList<String> ls = new ArrayList<String>();
        if (encabezado != null && !encabezado.isEmpty()) {
            ls.addAll(lineas(encabezado));
            ls.add("");
        }
        for (int i = 0; i < opciones.length; i++) {
            ls.add(Colores.pintar((i + 1) + ")", Colores.AZUL) + " " + opciones[i]);
        }
        Consola.cuadro(titulo, Colores.DORADO, ls, false);
        while (true) {
            Consola.prompt();
            String t = leer().trim();
            try {
                int n = Integer.parseInt(t);
                if (n >= 1 && n <= opciones.length) return n - 1;
            } catch (NumberFormatException e) {
                // no era un número: se vuelve a pedir
            }
            Consola.fallo("Escribe un número entre 1 y " + opciones.length + ".");
        }
    }

    @Override
    public String pedirTexto(String titulo, String pregunta) {
        System.out.println();
        Consola.info(pregunta);
        Consola.prompt();
        return leer();
    }

    @Override
    public boolean confirmar(String titulo, String pregunta) {
        System.out.println();
        Consola.info(pregunta.replace("\n", " ") + " (s/n)");
        while (true) {
            Consola.prompt();
            String t = leer().trim().toLowerCase();
            if (t.equals("s") || t.equals("si") || t.equals("sí")) return true;
            if (t.equals("n") || t.equals("no")) return false;
            Consola.fallo("Responde s o n.");
        }
    }

    @Override
    public void aviso(TipoAviso tipo, String titulo, String texto) {
        String icono;
        int color;
        switch (tipo) {
            case EXITO: icono = Iconos.correcto(); color = Colores.VERDE; break;
            case FALLO: icono = Iconos.error();    color = Colores.ROJO;  break;
            default:    icono = Iconos.libro();    color = Colores.AZUL;  break;
        }
        System.out.println();
        System.out.println(icono + " " + Colores.destacar(titulo, color));
        for (String l : texto.split("\n")) System.out.println("   " + l);
    }

    @Override
    public void recompensa(String titulo, String detalle, int xp, int monedas) {
        aviso(TipoAviso.EXITO, titulo, detalle);
        System.out.print("   ");
        Consola.recompensa(xp, monedas);
    }

    @Override
    public void subidaNivel(int nivel, String titulo, String desbloqueo) {
        System.out.println();
        Consola.subidaNivel(nivel, titulo, desbloqueo);
    }

    @Override
    public void estado(Usuario u) {
        System.out.println();
        Consola.hud(u.getNombre(), u.getTitulo(), u.getNivel(), u.getVidas(), u.getVidasMaximas(),
                u.getMonedas(), u.getExperiencia(), u.xpParaSiguienteNivel());
        ArrayList<String> ls = new ArrayList<String>();
        ls.add("Habilidad: " + Colores.destacar(u.getMejorHabilidad().getNombre(), Colores.CIAN));
        ls.add(Colores.tenue(u.getMejorHabilidad().getDescripcion()));
        ls.add("Multiplicador de XP: x" + u.getMultiplicadorXP());
        if (u.isEscudoActivo()) ls.add(Iconos.escudo() + " Escudo activo");
        if (u.isPistaActiva()) ls.add(Iconos.bombilla() + " Pista preparada");
        ls.add("");
        if (u.getInventario().estaVacio()) {
            ls.add("Inventario: vacío");
        } else {
            ls.add("Inventario (" + u.getInventario().getCantidad() + "/8):");
            for (ItemEquipable item : u.getInventario().getItems()) ls.add("  • " + item.getNombre());
        }
        Consola.cuadro("Estado", Colores.VERDE, ls, false);
    }

    @Override
    public String preguntar(Enemigo e, Usuario u, String pista) {
        System.out.println();
        Consola.enemigo(e.getEtiqueta() + e.getNombre(), e.getCategoria().getEtiqueta(),
                e.getVida(), e.getVidaMaxima(), e.getPregunta(), e.getOpciones());
        System.out.println(Colores.tenue("Vidas: " + u.getVidas() + "/" + u.getVidasMaximas()
                + "   Monedas: " + u.getMonedas()));
        if (pista != null) Consola.info(Iconos.bombilla() + " " + pista);

        String[] opciones = e.getOpciones();
        if (opciones != null) {
            Consola.info("Elige una letra (a, b, c...) o escribe 'huir'.");
        } else {
            Consola.info("Escribe tu respuesta, o 'huir' para escapar.");
        }
        while (true) {
            Consola.prompt();
            String t = leer().trim();
            if (t.equalsIgnoreCase("huir")) return null;
            if (opciones == null) return t;
            if (t.length() == 1) {
                int idx = Character.toLowerCase(t.charAt(0)) - 'a';
                if (idx >= 0 && idx < opciones.length) return opciones[idx];
            }
            Consola.fallo("Elige una letra entre a y " + (char) ('a' + opciones.length - 1) + ".");
        }
    }

    @Override
    public int menuExploracion(Usuario u, String nivel, String lugar, String descripcion,
                               String minimapa, String[] opciones) {
        System.out.println();
        Consola.hud(u.getNombre(), u.getTitulo(), u.getNivel(), u.getVidas(), u.getVidasMaximas(),
                u.getMonedas(), u.getExperiencia(), u.xpParaSiguienteNivel());
        ArrayList<String> ls = new ArrayList<String>();
        ls.add(Colores.tenue(nivel));
        ls.add(Colores.negrita(descripcion));
        ls.add("");
        ls.addAll(lineas(minimapa));
        ls.add("");
        ls.add(Colores.tenue("@ tú · ? sin explorar · E enemigo · T tienda · K/C cofre · L puerta · J jefe"));
        Consola.cuadro(Iconos.mapa() + " " + lugar, Colores.CIAN, ls, false);
        return menu("¿Qué haces?", null, opciones);
    }
}
