package rpgacademico.vista;

import rpgacademico.enemigos.Enemigo;
import rpgacademico.modelo.Usuario;

/**
 * Todo lo que el juego necesita mostrar o preguntar.
 * Tiene dos implementaciones: VistaJOptionPane (ventanas) y VistaConsola (terminal).
 * La lógica del juego solo conoce esta interfaz (polimorfismo).
 */
public interface Vista {

    void bienvenida();

    /** Texto de historia o ayuda. */
    void narrar(String titulo, String texto);

    /** Menú de opciones. Devuelve la posición elegida o -1 si el jugador cierra la ventana. */
    int menu(String titulo, String encabezado, String[] opciones);

    /** Pide un texto. Devuelve null si el jugador cancela. */
    String pedirTexto(String titulo, String pregunta);

    boolean confirmar(String titulo, String pregunta);

    void aviso(TipoAviso tipo, String titulo, String texto);

    void recompensa(String titulo, String detalle, int xp, int monedas);

    void subidaNivel(int nivel, String titulo, String desbloqueo);

    void estado(Usuario usuario);

    /** Muestra la pregunta y devuelve la respuesta, o null si el jugador quiere huir. */
    String preguntar(Enemigo enemigo, Usuario usuario, String pista);

    /** Menú principal de exploración con el minimapa. */
    int menuExploracion(Usuario usuario, String nivel, String lugar, String descripcion,
                        String minimapa, String[] opciones);
}
