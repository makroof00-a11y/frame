package rpgacademico.vista;

/**
 * Paleta de colores ANSI (256 colores) para la consola.
 * Si la terminal no los soporta, llama a Colores.setActivo(false).
 */
public final class Colores {

    // Paleta sobria y elegante
    public static final int DORADO  = 220;
    public static final int VERDE   = 78;
    public static final int ROJO    = 203;
    public static final int AZUL    = 75;
    public static final int MORADO  = 141;
    public static final int CIAN    = 80;
    public static final int NARANJA = 209;
    public static final int GRIS    = 245;
    public static final int BLANCO  = 255;

    private static final String RESET = "\u001B[0m";
    private static boolean activo = true;

    private Colores() { }

    public static void setActivo(boolean valor) { activo = valor; }
    public static boolean isActivo() { return activo; }

    public static String pintar(String texto, int color) {
        if (!activo) return texto;
        return "\u001B[38;5;" + color + "m" + texto + RESET;
    }

    public static String negrita(String texto) {
        if (!activo) return texto;
        return "\u001B[1m" + texto + RESET;
    }

    public static String tenue(String texto) {
        if (!activo) return texto;
        return "\u001B[2m" + texto + RESET;
    }

    /** Color + negrita a la vez. */
    public static String destacar(String texto, int color) {
        if (!activo) return texto;
        return "\u001B[1;38;5;" + color + "m" + texto + RESET;
    }
}
