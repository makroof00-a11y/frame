package rpgacademico.vista;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Dibuja toda la interfaz de texto: cajas, barras, HUD y mensajes.
 * Calcula el ancho visible de cada línea (ignorando códigos ANSI y
 * contando los emojis como 2 columnas) para que los bordes queden alineados.
 */
public final class Consola {

    public static final int ANCHO = 64;
    private static final int INTERIOR = ANCHO - 4; // texto entre "│ " y " │"

    private Consola() { }

    // ------------------------------------------------------------------
    // Preparación
    // ------------------------------------------------------------------

    /** Fuerza salida UTF-8 para que los emojis y bordes se vean bien. */
    public static void iniciar() {
        try {
            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out), true, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            // Si falla, se queda con la salida por defecto
        }
    }

    public static void limpiar() {
        if (Colores.isActivo()) {
            System.out.print("\u001B[H\u001B[2J");
            System.out.flush();
        } else {
            for (int i = 0; i < 3; i++) System.out.println();
        }
    }

    // ------------------------------------------------------------------
    // Utilidades de texto
    // ------------------------------------------------------------------

    private static String repetir(String s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(s);
        return sb.toString();
    }

    /** Ancho en columnas de la terminal, sin contar códigos ANSI. */
    static int anchoVisible(String texto) {
        String limpio = texto.replaceAll("\u001B\\[[;\\d]*m", "");
        int ancho = 0;
        int i = 0;
        while (i < limpio.length()) {
            int cp = limpio.codePointAt(i);
            int n = Character.charCount(cp);
            boolean conVariacion = i + n < limpio.length()
                    && limpio.charAt(i + n) == '\uFE0F';
            if (cp == 0xFE0F || cp == 0x200D) {
                ancho += 0;
            } else if (cp >= 0x1F000 || conVariacion
                    || cp == 0x2B50 || cp == 0x2705 || cp == 0x274C || cp == 0x26A1) {
                ancho += 2;
            } else {
                ancho += 1;
            }
            i += n;
        }
        return ancho;
    }

    private static String rellenar(String texto, int ancho) {
        int falta = ancho - anchoVisible(texto);
        return falta > 0 ? texto + repetir(" ", falta) : texto;
    }

    public static String centrar(String texto, int ancho) {
        int falta = ancho - anchoVisible(texto);
        if (falta <= 0) return texto;
        int izq = falta / 2;
        return repetir(" ", izq) + texto + repetir(" ", falta - izq);
    }

    /** Parte un texto largo en líneas que caben dentro de la caja. */
    public static List<String> envolver(String texto, int ancho) {
        List<String> lineas = new ArrayList<String>();
        StringBuilder actual = new StringBuilder();
        for (String palabra : texto.split(" ")) {
            if (actual.length() > 0
                    && anchoVisible(actual.toString()) + 1 + anchoVisible(palabra) > ancho) {
                lineas.add(actual.toString());
                actual.setLength(0);
            }
            if (actual.length() > 0) actual.append(' ');
            actual.append(palabra);
        }
        if (actual.length() > 0) lineas.add(actual.toString());
        return lineas;
    }

    // ------------------------------------------------------------------
    // Cajas
    // ------------------------------------------------------------------

    public static void cuadro(String titulo, int color, String... lineas) {
        cuadro(titulo, color, Arrays.asList(lineas), false);
    }

    public static void cuadro(String titulo, int color, List<String> lineas, boolean doble) {
        String h = doble ? "═" : "─";
        String v = doble ? "║" : "│";
        String tl = doble ? "╔" : "╭";
        String tr = doble ? "╗" : "╮";
        String bl = doble ? "╚" : "╰";
        String br = doble ? "╝" : "╯";

        int interior = ANCHO - 2;
        String encabezado;
        if (titulo == null || titulo.isEmpty()) {
            encabezado = Colores.pintar(tl + repetir(h, interior) + tr, color);
        } else {
            int guiones = Math.max(interior - 3 - anchoVisible(titulo), 0);
            encabezado = Colores.pintar(tl + h + " ", color)
                    + Colores.destacar(titulo, color)
                    + Colores.pintar(" " + repetir(h, guiones) + tr, color);
        }
        System.out.println(encabezado);

        String borde = Colores.pintar(v, color);
        for (String linea : lineas) {
            if (anchoVisible(linea) <= INTERIOR) {
                // Cabe completa: se conserva tal cual (centrado, sangría, vacía)
                System.out.println(borde + " " + rellenar(linea, INTERIOR) + " " + borde);
            } else {
                for (String parte : envolver(linea, INTERIOR)) {
                    System.out.println(borde + " " + rellenar(parte, INTERIOR) + " " + borde);
                }
            }
        }
        System.out.println(Colores.pintar(bl + repetir(h, interior) + br, color));
    }

    public static void separador() {
        System.out.println(Colores.tenue(repetir("─", ANCHO)));
    }

    // ------------------------------------------------------------------
    // Barras y HUD
    // ------------------------------------------------------------------

    public static String barra(int actual, int max, int largo, int color) {
        int llenos = max <= 0 ? 0 : Math.min(largo, Math.max(0, actual * largo / max));
        return Colores.pintar(repetir("█", llenos), color)
                + Colores.pintar(repetir("░", largo - llenos), Colores.GRIS);
    }

    private static String corazones(int vidas, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < max; i++) {
            sb.append(i < vidas ? Iconos.corazon() : Colores.tenue("·")).append(' ');
        }
        return sb.toString().trim();
    }

    /** Panel superior con el estado del jugador. */
    public static void hud(String nombre, String titulo, int nivel, int vidas, int vidasMax,
                           int monedas, int xp, int xpMax) {
        String fila1 = Iconos.castillo() + " " + Colores.destacar(nombre, Colores.BLANCO)
                + Colores.tenue("  ·  ") + Colores.pintar(titulo, Colores.MORADO)
                + Colores.tenue("  ·  ") + "Nivel " + Colores.destacar(String.valueOf(nivel), Colores.DORADO);
        String fila2 = corazones(vidas, vidasMax) + "    "
                + Iconos.moneda() + " " + Colores.pintar(String.valueOf(monedas), Colores.DORADO);
        String fila3 = Iconos.estrella() + " XP " + barra(xp, xpMax, 24, Colores.VERDE)
                + " " + Colores.tenue(xp + "/" + xpMax);
        cuadro("EL REINO DEL CÓDIGO", Colores.DORADO, Arrays.asList(fila1, fila2, fila3), false);
    }

    // ------------------------------------------------------------------
    // Combate
    // ------------------------------------------------------------------

    public static void enemigo(String nombre, String categoria, int vida, int vidaMax,
                               String pregunta, String[] opciones) {
        List<String> lineas = new ArrayList<String>();
        lineas.add(Colores.tenue("Categoría: ") + Colores.pintar(categoria, Colores.CIAN));
        lineas.add(Iconos.corazon() + " " + barra(vida, vidaMax, 24, Colores.ROJO)
                + " " + Colores.tenue(vida + "/" + vidaMax));
        lineas.add("");
        lineas.add(Colores.negrita(pregunta));
        if (opciones != null && opciones.length > 0) {
            lineas.add("");
            char letra = 'a';
            for (String op : opciones) {
                lineas.add("  " + Colores.pintar(letra + ")", Colores.AZUL) + " " + op);
                letra++;
            }
        }
        cuadro(Iconos.espadas() + " " + nombre, Colores.ROJO, lineas, false);
    }

    // ------------------------------------------------------------------
    // Mensajes
    // ------------------------------------------------------------------

    public static void exito(String texto) {
        System.out.println(Iconos.correcto() + " " + Colores.pintar(texto, Colores.VERDE));
    }

    public static void fallo(String texto) {
        System.out.println(Iconos.error() + " " + Colores.pintar(texto, Colores.ROJO));
    }

    public static void info(String texto) {
        System.out.println(Colores.pintar("›", Colores.AZUL) + " " + texto);
    }

    public static void recompensa(int xp, int monedas) {
        System.out.println(Iconos.estrella() + " " + Colores.destacar("+" + xp + " XP", Colores.VERDE)
                + Colores.tenue("   ") + Iconos.moneda() + " "
                + Colores.destacar("+" + monedas, Colores.DORADO));
    }

    public static void subidaNivel(int nivel, String titulo, String desbloqueo) {
        List<String> lineas = new ArrayList<String>();
        lineas.add(centrar(Iconos.fiesta() + "  " + Colores.destacar("¡SUBISTE DE NIVEL!", Colores.DORADO)
                + "  " + Iconos.fiesta(), INTERIOR));
        lineas.add(centrar("Ahora eres " + Colores.destacar("Nivel " + nivel, Colores.BLANCO)
                + " · " + Colores.pintar(titulo, Colores.MORADO), INTERIOR));
        if (desbloqueo != null) {
            lineas.add(centrar(Iconos.rayo() + " Desbloqueaste: "
                    + Colores.destacar(desbloqueo, Colores.CIAN), INTERIOR));
        }
        cuadro(null, Colores.DORADO, lineas, true);
    }

    public static void prompt() {
        System.out.print(Colores.destacar("❯ ", Colores.DORADO));
        System.out.flush();
    }

    /** Efecto de máquina de escribir para la narrativa. */
    public static void escribir(String texto, int msPorLetra) {
        for (String linea : envolver(texto, ANCHO)) {
            for (char c : linea.toCharArray()) {
                System.out.print(c);
                System.out.flush();
                if (msPorLetra > 0) {
                    try {
                        Thread.sleep(msPorLetra);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        msPorLetra = 0;
                    }
                }
            }
            System.out.println();
        }
    }

    /** Pantalla de bienvenida. */
    public static void banner() {
        String linea = Colores.destacar("E L   R E I N O   D E L   C Ó D I G O", Colores.DORADO);
        List<String> lineas = new ArrayList<String>();
        lineas.add("");
        lineas.add(centrar(Iconos.castillo(), INTERIOR));
        lineas.add(centrar(linea, INTERIOR));
        lineas.add(centrar(Colores.tenue("Aprende, combate y sube de nivel"), INTERIOR));
        lineas.add("");
        cuadro(null, Colores.DORADO, lineas, true);
    }
}
