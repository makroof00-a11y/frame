package rpgacademico.excepciones;

/** Excepción base de todo el juego (jerarquía de excepciones propias). */
public class ReinoException extends Exception {
    private static final long serialVersionUID = 1L;

    public ReinoException(String mensaje) { super(mensaje); }
    public ReinoException(String mensaje, Throwable causa) { super(mensaje, causa); }
}
