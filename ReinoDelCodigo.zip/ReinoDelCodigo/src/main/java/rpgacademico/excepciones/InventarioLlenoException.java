package rpgacademico.excepciones;

public class InventarioLlenoException extends ReinoException {
    private static final long serialVersionUID = 1L;

    public InventarioLlenoException(String mensaje) { super(mensaje); }
}
