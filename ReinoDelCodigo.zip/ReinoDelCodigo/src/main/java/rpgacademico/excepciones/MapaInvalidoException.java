package rpgacademico.excepciones;

public class MapaInvalidoException extends ReinoException {
    private static final long serialVersionUID = 1L;

    public MapaInvalidoException(String mensaje) { super(mensaje); }
    public MapaInvalidoException(String mensaje, Throwable causa) { super(mensaje, causa); }
}
