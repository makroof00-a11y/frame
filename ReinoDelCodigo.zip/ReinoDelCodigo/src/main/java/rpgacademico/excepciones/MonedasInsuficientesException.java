package rpgacademico.excepciones;

public class MonedasInsuficientesException extends ReinoException {
    private static final long serialVersionUID = 1L;

    public MonedasInsuficientesException(String mensaje) { super(mensaje); }
}
