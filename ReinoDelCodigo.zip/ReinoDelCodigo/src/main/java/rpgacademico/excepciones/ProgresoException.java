package rpgacademico.excepciones;

public class ProgresoException extends ReinoException {
    private static final long serialVersionUID = 1L;

    public ProgresoException(String mensaje) { super(mensaje); }
    public ProgresoException(String mensaje, Throwable causa) { super(mensaje, causa); }
}
