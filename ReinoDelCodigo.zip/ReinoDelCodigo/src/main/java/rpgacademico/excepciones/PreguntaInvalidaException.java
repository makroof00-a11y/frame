package rpgacademico.excepciones;

public class PreguntaInvalidaException extends ReinoException {
    private static final long serialVersionUID = 1L;

    public PreguntaInvalidaException(String mensaje) { super(mensaje); }
    public PreguntaInvalidaException(String mensaje, Throwable causa) { super(mensaje, causa); }
}
