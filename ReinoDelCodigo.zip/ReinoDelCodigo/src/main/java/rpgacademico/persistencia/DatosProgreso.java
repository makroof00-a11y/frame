package rpgacademico.persistencia;

import rpgacademico.modelo.ModoJuego;
import rpgacademico.modelo.Usuario;

/** Lo que se recupera al cargar una partida. */
public class DatosProgreso {

    private final Usuario usuario;
    private final ModoJuego modo;
    private final int nivelMapa;

    public DatosProgreso(Usuario usuario, ModoJuego modo, int nivelMapa) {
        this.usuario = usuario;
        this.modo = modo;
        this.nivelMapa = nivelMapa;
    }

    public Usuario getUsuario() { return usuario; }
    public ModoJuego getModo() { return modo; }
    public int getNivelMapa() { return nivelMapa; }
}
