package rpgacademico.persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import rpgacademico.excepciones.InventarioLlenoException;
import rpgacademico.excepciones.ProgresoException;
import rpgacademico.items.FabricaItems;
import rpgacademico.items.ItemEquipable;
import rpgacademico.modelo.ModoJuego;
import rpgacademico.modelo.Usuario;

/** Guarda y carga la partida en un archivo de texto (clave=valor). */
public final class GuardadoProgreso {

    public static final String ARCHIVO = "progreso.txt";

    private GuardadoProgreso() { }

    public static boolean existe() { return new File(ARCHIVO).exists(); }

    public static void guardar(Usuario u, ModoJuego modo, int nivelMapa) throws ProgresoException {
        StringBuilder items = new StringBuilder();
        for (ItemEquipable item : u.getInventario().getItems()) {
            if (items.length() > 0) items.append(',');
            items.append(item.getId());
        }
        try (BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(ARCHIVO), StandardCharsets.UTF_8))) {
            escribir(out, "nombre", u.getNombre());
            escribir(out, "modo", modo.name());
            escribir(out, "nivelMapa", String.valueOf(nivelMapa));
            escribir(out, "nivelJugador", String.valueOf(u.getNivel()));
            escribir(out, "experiencia", String.valueOf(u.getExperiencia()));
            escribir(out, "vidas", String.valueOf(u.getVidas()));
            escribir(out, "vidasMaximas", String.valueOf(u.getVidasMaximas()));
            escribir(out, "monedas", String.valueOf(u.getMonedas()));
            escribir(out, "multiplicador", String.valueOf(u.getMultiplicadorXP()));
            escribir(out, "items", items.toString());
        } catch (IOException e) {
            throw new ProgresoException("No se pudo guardar la partida: " + e.getMessage(), e);
        }
    }

    private static void escribir(BufferedWriter out, String clave, String valor) throws IOException {
        out.write(clave + "=" + valor);
        out.newLine();
    }

    public static DatosProgreso cargar() throws ProgresoException {
        HashMap<String, String> datos = new HashMap<String, String>();
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(new FileInputStream(ARCHIVO), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = in.readLine()) != null) {
                int i = linea.indexOf('=');
                if (i > 0) datos.put(linea.substring(0, i).trim(), linea.substring(i + 1).trim());
            }
        } catch (IOException e) {
            throw new ProgresoException("No se pudo leer la partida guardada: " + e.getMessage(), e);
        }

        try {
            Usuario u = new Usuario(requerido(datos, "nombre"));
            ModoJuego modo = ModoJuego.valueOf(requerido(datos, "modo"));
            int nivelMapa = Integer.parseInt(requerido(datos, "nivelMapa"));
            if (nivelMapa < 1 || nivelMapa > 3) {
                throw new ProgresoException("El nivel guardado (" + nivelMapa + ") no es válido.");
            }
            u.restaurarEstado(
                    Integer.parseInt(requerido(datos, "nivelJugador")),
                    Integer.parseInt(requerido(datos, "experiencia")),
                    Integer.parseInt(requerido(datos, "vidas")),
                    Integer.parseInt(requerido(datos, "vidasMaximas")),
                    Integer.parseInt(requerido(datos, "monedas")),
                    Double.parseDouble(requerido(datos, "multiplicador")));
            String items = datos.get("items");
            if (items != null && !items.isEmpty()) {
                for (String id : items.split(",")) {
                    u.getInventario().agregar(FabricaItems.crear(id.trim()));
                }
            }
            return new DatosProgreso(u, modo, nivelMapa);
        } catch (IllegalArgumentException | InventarioLlenoException e) {
            // IllegalArgumentException incluye NumberFormatException y valueOf inválido
            throw new ProgresoException("El archivo de progreso está dañado: " + e.getMessage(), e);
        }
    }

    private static String requerido(HashMap<String, String> datos, String clave) throws ProgresoException {
        String valor = datos.get(clave);
        if (valor == null) throw new ProgresoException("Falta el dato '" + clave + "' en " + ARCHIVO + ".");
        return valor;
    }
}
