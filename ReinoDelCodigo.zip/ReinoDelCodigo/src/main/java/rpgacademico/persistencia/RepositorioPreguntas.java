package rpgacademico.persistencia;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import rpgacademico.enemigos.Enemigo;
import rpgacademico.enemigos.FabricaEnemigos;
import rpgacademico.excepciones.PreguntaInvalidaException;
import rpgacademico.modelo.ModoJuego;

/** Carga las preguntas desde un archivo y las reparte sin repetirlas. */
public class RepositorioPreguntas {

    private final ArrayList<Enemigo> banco = new ArrayList<Enemigo>();
    private final ArrayList<Enemigo> usadas = new ArrayList<Enemigo>();
    private final Random azar = new Random();

    /** Lee el archivo línea por línea. Las líneas vacías y las que empiezan con // se ignoran. */
    public void cargar(String archivo) throws PreguntaInvalidaException {
        ArrayList<String> lineas;
        try {
            lineas = Recursos.leerLineas(archivo);
        } catch (IOException e) {
            throw new PreguntaInvalidaException("No se pudo leer " + archivo + ": " + e.getMessage(), e);
        }
        banco.clear();
        usadas.clear();
        for (int i = 0; i < lineas.size(); i++) {
            String linea = lineas.get(i).trim();
            if (linea.isEmpty() || linea.startsWith("//")) continue;
            banco.add(FabricaEnemigos.desdeLinea(linea, i + 1));
        }
        if (banco.isEmpty()) {
            throw new PreguntaInvalidaException("El archivo " + archivo + " no tiene preguntas.");
        }
    }

    /** Entrega una pregunta al azar de la dificultad pedida, compatible con el modo de juego. */
    public Enemigo siguiente(int dificultad, ModoJuego modo) throws PreguntaInvalidaException {
        ArrayList<Enemigo> candidatas = filtrar(dificultad, modo, true);
        if (candidatas.isEmpty()) {
            // Se acabaron las preguntas nuevas: se vuelven a habilitar las ya usadas
            usadas.removeAll(filtrar(dificultad, modo, false));
            candidatas = filtrar(dificultad, modo, true);
        }
        if (candidatas.isEmpty()) {
            throw new PreguntaInvalidaException("No hay preguntas de dificultad " + dificultad
                    + " para el modo " + modo.getEtiqueta() + ".");
        }
        Enemigo elegido = candidatas.get(azar.nextInt(candidatas.size()));
        usadas.add(elegido);
        elegido.restaurar();
        return elegido;
    }

    private ArrayList<Enemigo> filtrar(int dificultad, ModoJuego modo, boolean soloNoUsadas) {
        ArrayList<Enemigo> resultado = new ArrayList<Enemigo>();
        for (Enemigo e : banco) {
            boolean coincide = e.getDificultad() == dificultad && modo.acepta(e.getCategoria());
            boolean disponible = !usadas.contains(e);
            if (coincide && (soloNoUsadas ? disponible : !disponible)) resultado.add(e);
        }
        return resultado;
    }

    public int getTotalPreguntas() { return banco.size(); }
}
