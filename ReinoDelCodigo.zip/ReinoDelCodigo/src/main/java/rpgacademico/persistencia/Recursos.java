package rpgacademico.persistencia;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Lectura de archivos de texto de la carpeta recursos/ (mapas, preguntas, instrucciones). */
public final class Recursos {

    private static final String CARPETA = "recursos";

    private Recursos() { }

    /** Lee todas las líneas del archivo. Busca en recursos/ y, si no está, dentro del classpath. */
    public static ArrayList<String> leerLineas(String archivo) throws IOException {
        InputStream flujo;
        File enDisco = new File(CARPETA, archivo);
        if (enDisco.exists()) {
            flujo = new FileInputStream(enDisco);
        } else {
            flujo = Recursos.class.getResourceAsStream("/" + CARPETA + "/" + archivo);
            if (flujo == null) {
                throw new IOException("No se encontró el archivo " + CARPETA + "/" + archivo
                        + " (revisa que la carpeta 'recursos' esté junto a 'src').");
            }
        }

        ArrayList<String> lineas = new ArrayList<String>();
        try (BufferedReader lector = new BufferedReader(new InputStreamReader(flujo, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (lineas.isEmpty() && !linea.isEmpty() && linea.charAt(0) == '\uFEFF') {
                    linea = linea.substring(1);   // quita la marca BOM si la hay
                }
                lineas.add(linea);
            }
        }
        return lineas;
    }
}
