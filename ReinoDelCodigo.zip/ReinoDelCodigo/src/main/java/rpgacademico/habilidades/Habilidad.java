package rpgacademico.habilidades;

/** Clase abstracta: cada habilidad calcula su daño de forma distinta (polimorfismo). */
public abstract class Habilidad {

    private final String nombre;
    private final int nivelRequerido;

    protected Habilidad(String nombre, int nivelRequerido) {
        this.nombre = nombre;
        this.nivelRequerido = nivelRequerido;
    }

    /** Daño que causa al enemigo según los intentos usados y los segundos que tardó. */
    public abstract int calcularDanio(int intentos, long segundos);

    public abstract String getDescripcion();

    /** Texto extra del último golpe (por ejemplo, "¡Golpe crítico!"). */
    public String describirUltimoGolpe() { return ""; }

    public String getNombre() { return nombre; }

    public int getNivelRequerido() { return nivelRequerido; }
}
