package rpgacademico.habilidades;

/** Daño fijo. Disponible desde el nivel 1. */
public class MetodoCorrecto extends Habilidad {

    public MetodoCorrecto() { super("Método Correcto", 1); }

    @Override
    public int calcularDanio(int intentos, long segundos) { return 30; }

    @Override
    public String getDescripcion() { return "Daño fijo de 30."; }
}
