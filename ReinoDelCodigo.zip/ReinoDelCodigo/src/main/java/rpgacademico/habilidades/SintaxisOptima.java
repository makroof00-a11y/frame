package rpgacademico.habilidades;

/** Daño extra si aciertas al primer intento y con rapidez. Nivel 2. */
public class SintaxisOptima extends Habilidad {

    public SintaxisOptima() { super("Sintaxis Óptima", 2); }

    @Override
    public int calcularDanio(int intentos, long segundos) {
        int danio = 30;
        if (intentos == 1) danio += 10;
        if (segundos < 15) danio += 10;
        return danio;
    }

    @Override
    public String getDescripcion() { return "30 de daño, +10 al primer intento, +10 si respondes en menos de 15 s."; }
}
