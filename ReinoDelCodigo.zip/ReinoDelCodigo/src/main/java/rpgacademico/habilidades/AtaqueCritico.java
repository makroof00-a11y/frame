package rpgacademico.habilidades;

import java.util.Random;

/** Daño alto con 25 % de probabilidad de golpe crítico (x2). Nivel 3. */
public class AtaqueCritico extends Habilidad {

    private final Random azar = new Random();
    private boolean ultimoFueCritico = false;

    public AtaqueCritico() { super("Ataque Crítico", 3); }

    @Override
    public int calcularDanio(int intentos, long segundos) {
        int danio = 40;
        if (intentos == 1) danio += 10;
        ultimoFueCritico = azar.nextInt(100) < 25;
        return ultimoFueCritico ? danio * 2 : danio;
    }

    @Override
    public String describirUltimoGolpe() {
        return ultimoFueCritico ? "¡GOLPE CRÍTICO! Daño doble." : "";
    }

    @Override
    public String getDescripcion() { return "40 de daño (+10 al primer intento) y 25 % de golpe crítico x2."; }
}
