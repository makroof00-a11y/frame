package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Abre la puerta sellada que protege al jefe del nivel. Se usa sola al llegar a la puerta. */
public class LlaveCompilacion implements ItemEquipable {
    public static final String ID = "LLAVE";

    @Override public String getId() { return ID; }
    @Override public String getNombre() { return "Llave de Compilación"; }
    @Override public String getDescripcion() { return "Abre la puerta sellada (se usa sola)."; }
    @Override public int getPrecio() { return 0; }
    @Override public boolean esConsumible() { return true; }

    @Override
    public boolean puedeUsarse(Usuario usuario) { return false; }

    @Override
    public String usar(Usuario usuario) { return "La llave se usa sola al llegar a la puerta sellada."; }
}
