package rpgacademico.items;

import java.util.Random;

/** Crea objetos a partir de su identificador (patrón Factory). */
public final class FabricaItems {

    private FabricaItems() { }

    public static ItemEquipable crear(String id) {
        switch (id) {
            case EscudoCompilacion.ID: return new EscudoCompilacion();
            case PocionPistas.ID:      return new PocionPistas();
            case PocionVida.ID:        return new PocionVida();
            case AmuletoXP.ID:         return new AmuletoXP();
            case LlaveCompilacion.ID:  return new LlaveCompilacion();
            default: throw new IllegalArgumentException("Objeto desconocido: " + id);
        }
    }

    /** Objeto de recompensa al azar para los cofres. */
    public static ItemEquipable aleatorio(Random azar) {
        String[] ids = { EscudoCompilacion.ID, PocionPistas.ID, PocionVida.ID };
        return crear(ids[azar.nextInt(ids.length)]);
    }
}
