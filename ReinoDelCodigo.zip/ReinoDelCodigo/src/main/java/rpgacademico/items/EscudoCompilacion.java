package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Te protege de perder una vida la próxima vez que falles. */
public class EscudoCompilacion implements ItemEquipable {
    public static final String ID = "ESCUDO";

    @Override public String getId() { return ID; }
    @Override public String getNombre() { return "Escudo de Compilación"; }
    @Override public String getDescripcion() { return "Absorbe el próximo fallo sin perder vida."; }
    @Override public int getPrecio() { return 50; }
    @Override public boolean esConsumible() { return true; }

    @Override
    public boolean puedeUsarse(Usuario usuario) { return !usuario.isEscudoActivo(); }

    @Override
    public String usar(Usuario usuario) {
        usuario.activarEscudo();
        return "Escudo activado: el próximo fallo no te quitará vida.";
    }
}
