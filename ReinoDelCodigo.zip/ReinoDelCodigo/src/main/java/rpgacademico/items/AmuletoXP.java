package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Multiplica por 1.5 toda la experiencia que ganes (efecto permanente). */
public class AmuletoXP implements ItemEquipable {
    public static final String ID = "AMULETO";

    @Override public String getId() { return ID; }
    @Override public String getNombre() { return "Amuleto de Experiencia"; }
    @Override public String getDescripcion() { return "Ganas 50 % más de experiencia, para siempre."; }
    @Override public int getPrecio() { return 80; }
    @Override public boolean esConsumible() { return true; }

    @Override
    public boolean puedeUsarse(Usuario usuario) { return usuario.getMultiplicadorXP() < 1.5; }

    @Override
    public String usar(Usuario usuario) {
        usuario.setMultiplicadorXP(1.5);
        return "Te pones el amuleto: ahora ganas x1.5 de experiencia.";
    }
}
