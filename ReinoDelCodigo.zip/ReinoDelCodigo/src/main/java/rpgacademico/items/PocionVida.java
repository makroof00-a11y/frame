package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Recupera una vida. */
public class PocionVida implements ItemEquipable {
    public static final String ID = "VIDA";

    @Override public String getId() { return ID; }
    @Override public String getNombre() { return "Poción de Vida"; }
    @Override public String getDescripcion() { return "Recupera 1 vida."; }
    @Override public int getPrecio() { return 40; }
    @Override public boolean esConsumible() { return true; }

    @Override
    public boolean puedeUsarse(Usuario usuario) { return usuario.getVidas() < usuario.getVidasMaximas(); }

    @Override
    public String usar(Usuario usuario) {
        usuario.sanar();
        return "Recuperaste una vida (" + usuario.getVidas() + "/" + usuario.getVidasMaximas() + ").";
    }
}
