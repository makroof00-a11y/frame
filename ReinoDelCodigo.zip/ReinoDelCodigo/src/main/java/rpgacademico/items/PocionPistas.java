package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Revela una pista en la próxima pregunta. */
public class PocionPistas implements ItemEquipable {
    public static final String ID = "PISTA";

    @Override public String getId() { return ID; }
    @Override public String getNombre() { return "Poción de Pistas"; }
    @Override public String getDescripcion() { return "Da una pista en la próxima pregunta."; }
    @Override public int getPrecio() { return 30; }
    @Override public boolean esConsumible() { return true; }

    @Override
    public boolean puedeUsarse(Usuario usuario) { return !usuario.isPistaActiva(); }

    @Override
    public String usar(Usuario usuario) {
        usuario.activarPista();
        return "Poción bebida: recibirás una pista en la próxima pregunta.";
    }
}
