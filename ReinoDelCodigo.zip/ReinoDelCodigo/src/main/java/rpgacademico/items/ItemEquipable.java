package rpgacademico.items;

import rpgacademico.modelo.Usuario;

/** Interfaz de todos los objetos que se pueden guardar en el inventario y usar. */
public interface ItemEquipable {

    String getId();

    String getNombre();

    String getDescripcion();

    int getPrecio();

    /** Si es true, el objeto desaparece del inventario después de usarse. */
    boolean esConsumible();

    /** Indica si tiene sentido usarlo ahora (por ejemplo, no curar con la vida llena). */
    default boolean puedeUsarse(Usuario usuario) { return true; }

    /** Aplica el efecto y devuelve un mensaje para mostrar al jugador. */
    String usar(Usuario usuario);
}
